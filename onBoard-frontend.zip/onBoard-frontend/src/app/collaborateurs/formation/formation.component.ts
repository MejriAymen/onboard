import { Component, OnInit } from '@angular/core';
import { NbWindowService } from '@nebular/theme';
import { CertifWindowComponent } from '../../components/certif-window/certif-window.component';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment.prod';
@Component({
  selector: 'ngx-formation',
  templateUrl: './formation.component.html',
  styleUrls: ['./formation.component.scss']
})
export class FormationComponent implements OnInit {
  private link = environment.linklocal + "formations/";
  formations: any[];
  filteredFormations: any[];
  isRecommended: boolean = false;
  isRequired: boolean = false;
  constructor(private windowService: NbWindowService, private http: HttpClient) { }
  formationId: number;

  ngOnInit(): void {
    this.http.get<any[]>(this.link + 'get/all')
      .subscribe(data => {
        this.formations = data;
        this.formations.forEach(formation => {
          formation.id = formation.idFormation;
          formation.departement = formation.departement.name;
        });
        this.filteredFormations = this.formations;


      });
  }

  onClickGo(link: string) {
    window.open(link, '_blank');
  }

  filterFormations(searchTerm: string = '') {
    this.filteredFormations = this.formations.filter(formation => {
      const matchesRecommended = !this.isRecommended || !formation.obligatory;
      const matchesRequired = !this.isRequired || formation.obligatory;
      const matchesTitle = !searchTerm || formation.titleForm.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesDepartment = formation.departement.toLowerCase().includes(searchTerm.toLowerCase());
      return (matchesRecommended && matchesRequired) && (matchesTitle || matchesDepartment);
    });
  }


  openFileUploadWindow(formationId: number) {

    this.windowService.open(
      CertifWindowComponent, // Component to be displayed in the modal window
      { title: 'Veuillez télécharger votre certificat', windowClass: 'file-upload-modal', context: { formationId: formationId } } // Configuration for the modal window
    );
  }
}

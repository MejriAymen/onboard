import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CollaborateursComponent } from './collaborateurs.components';
import { HomeComponent } from '../home/home.component';
import { NotFoundComponent } from '../../pages/miscellaneous/not-found/not-found.component';
import { FormationComponent } from '../formation/formation.component';
import { DocsComponent } from '../docs/docs.component';
import { EvaluationComponent } from '../evaluation/evaluation.component';
import { SessionsComponent } from '../sessions/sessions.component';

const routes: Routes = [
  {
    path: 'collaborateurs',
    component: CollaborateursComponent,
    children: [
      {
        path: '',
        component: HomeComponent
      },
      {
        path: 'formation',
        component: FormationComponent
      },
      {
        path:'docs',
        component: DocsComponent
      },
      {
        path:'evaluation',
        component: EvaluationComponent
      },
      {
        path:'sessions',
        component: SessionsComponent
      },
  
      {
        path: '**',
        component: NotFoundComponent,
      },]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CollaborateursRoutingModule { 
  
}

import { Component } from '@angular/core';
import { LayoutService } from '../../@core/utils';
import{ MENU_ITEMS } from '../collaborateurs-menu';

@Component({
  selector: 'ngx-collaborateurs',
  styleUrls:['collaborateurs.scss'],
  template: `
   <ngx-one-column-layout>
    <nb-menu [items]="menu"> </nb-menu>
      <router-outlet></router-outlet>
    </ngx-one-column-layout>

  `,
})
export class CollaborateursComponent {
    constructor(private layoutService: LayoutService){
  
    }
  menu=MENU_ITEMS;
}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CollaborateursComponent } from './collaborateurs.components';
import { CollaborateursRoutingModule } from './collaborateurs-routing.module';
import { LayoutService } from '../../@core/utils';
import { ThemeModule } from "../../@theme/theme.module";
import { NbMenuModule } from '@nebular/theme';
@NgModule({
    declarations: [
        CollaborateursComponent
    ],
    exports: [CollaborateursRoutingModule],
    imports: [
        NbMenuModule,
        CommonModule,
        CollaborateursRoutingModule,
        ThemeModule
    ]
})
export class CollaborateursModule {

 }

import { Component, OnInit } from '@angular/core';
import { environment } from '../../../environments/environment.prod';
import { HttpClient } from '@angular/common/http';
import { NbToastrService } from '@nebular/theme';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'ngx-sessions',
  templateUrl: './sessions.component.html',
  styleUrls: ['./sessions.component.scss']
})
export class SessionsComponent implements OnInit {
  private link = environment.linklocal;
  data: any[];
  currentUserOnBoard : any ;
  constructor(private http: HttpClient,private toastr: NbToastrService,private datePipe: DatePipe) { }

  ngOnInit(): void {
    this.currentUserOnBoard=JSON.parse( localStorage.getItem('currentUserOnBoard'));
    this.loadData();
  }

  loadData(){
    this.http.get<any[]>(this.link + 'sessionParticipant/get/'+ this.currentUserOnBoard.id)
      .subscribe((data : any[]) => {
        this.data = data;
        console.log(data);
      });
  }

  report(event){
    this.http.put(this.link+'sessionParticipant/update/'+event+'/'+this.currentUserOnBoard.id, "REPORTE")
    .subscribe(() => {
      window.location.reload();
    }, (error) => {
      this.toastr.danger('Erreur lors de la modification', 'Erreur');
    });
  }

  accept(event){
    this.http.put(this.link+'sessionParticipant/update/'+event+'/'+this.currentUserOnBoard.id, "PRESENT")
    .subscribe(() => {
      window.location.reload();

    }, (error) => {
      this.toastr.danger('Erreur lors de la modification', 'Erreur');
    });
  }
  isWithinDateRange(startDate : Date, endDate: Date): boolean {
    const currentDate = new Date();
    return currentDate.getTime() <= new Date(endDate).getTime();
  }
  getIntegStautText(value): string {
    if (value === 'NOUVEAU') {
     return 'NOUVEAU';
   } else if (value === 'REPORTE') {
     return 'Reporté';
   } else if (value === 'ABSENT') {
     return 'Absent';
   } else if (value === 'FIGE') {
     return 'Figé';
   } else {
     return 'Validée';
   }
 }

 getIntegStautStatus(value): string {
   if (value === 'NOUVEAU') {
     return 'basic';
   } else if (value === 'REPORTE' || value === 'ABSENT') {
     return 'warning';
   } else if (value === 'FIGE') {
     return 'danger';
   } else {
     return 'success';
   }
 }
}

import { Component, OnInit } from '@angular/core';
import { NbToastrService } from '@nebular/theme';
import { environment } from '../../../environments/environment.prod';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'ngx-evaluation',
  templateUrl: './evaluation.component.html',
  styleUrls: ['./evaluation.component.scss']
})
export class EvaluationComponent implements OnInit {
  userRating: number; // Variable to store user's input
  evaluatedRating: number; // Variable to store evaluated rating
  isButtonDisabled: boolean = false; // Variable to control button's disabled state, initialized to false
  currentUserOnBoard : any ;
  private link = environment.linklocal;
  constructor(private http: HttpClient,private toastr: NbToastrService) { }

  ngOnInit(): void {
    this.currentUserOnBoard=JSON.parse( localStorage.getItem('currentUserOnBoard'));
   // this. getEvolutionIsExist();
  }


  getEvolutionIsExist(){
    this.http.get(this.link+'evolution/'+this.currentUserOnBoard.id)
      .subscribe((data) => {
  
      }, (error) => {
        this.toastr.danger('Erreur de récuperation data', 'Erreur');
      });
  }

  evaluateRating() {
    const evaluatedRating = Math.max(0, this.userRating);
    const evaluated = {
      evolution:evaluatedRating
    };
    this.isButtonDisabled = true; 


      this.http.get(this.link+'evolution/'+this.currentUserOnBoard.id+'/'+evaluatedRating)
      .subscribe(() => {
        this.toastr.success(`Evaluation: ${evaluatedRating}`, 'Evaluation avec succès'); 
  
      }, (error) => {
        this.toastr.danger('Erreur lors de la modification', 'Erreur');
      });
    
   
  }



}

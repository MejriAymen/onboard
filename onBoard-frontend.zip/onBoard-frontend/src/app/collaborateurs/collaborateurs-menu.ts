import { NbMenuItem } from '@nebular/theme';
export const MENU_ITEMS: NbMenuItem[] = [
  

  {
    title: 'Accueil',
    icon: 'home-outline',
    link: '/collaborateurs',
    home: true
    
  },
  {
    title: 'Formation',
    icon: 'edit-2',
    link: '/collaborateurs/formation',

    
  },
  {
    title: 'Documents de Safran',
    icon: 'file-text',
    link: '/collaborateurs/docs',

    
  },
  {
    title: 'Sessions à venir',
    icon: 'people',
    link: '/collaborateurs/sessions',

    
  },
  {
    title: 'Evaluation & clôture',
    icon: 'star-outline',
    link: '/collaborateurs/evaluation',

    
  }
  
];

import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NbToastrService } from '@nebular/theme';
import { catchError } from 'rxjs/operators';
import { saveAs } from 'file-saver';
import { environment } from '../../../environments/environment.prod';
@Component({
  selector: 'ngx-docs',
  templateUrl: './docs.component.html',
  styleUrls: ['./docs.component.scss']
})
export class DocsComponent implements OnInit {
  documents:any[];
  private link = environment.linklocal+"document/";
  constructor(private toastr: NbToastrService, private http: HttpClient) { }

  ngOnInit(): void {
    this.http.get<any[]>(this.link+"get/all")
    .subscribe(data => {
      this.documents = data;
      this.documents.forEach(document => document.id = document.idDocument);

    });
  }

  downloadDoc(document: any): void {
    this.http.get(this.link+'download/' + document.idDocument, {
      responseType: 'blob'
    }).pipe(
      catchError((error: HttpErrorResponse) => {
        this.toastr.danger('Une erreur est survenue lors du téléchargement du document.', 'Erreur');
        //console.log(error);
        return [];
      })
    ).subscribe((response: Blob) => {
      const file = new Blob([response], { type: 'application/pdf' }); 
      saveAs(file, document.titleDocument);
    });
  }
  showToastr(): void {
  this.toastr.warning('Veuillez lire le document avant de signer','ATTENTION!');}

}

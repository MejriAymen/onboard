import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment.prod';
@Component({
  selector: 'ngx-ceremonies',
  templateUrl: './ceremonies.component.html',
  styleUrls: ['./ceremonies.component.scss']
})
export class CeremoniesComponent{
  pdfs: any[];
  htmlContent: any;
  sessions: any[];
  sessionparticipant: any[];
  selectedRows: any[] = [];
  cols =  [
    'matricule','nom','prenom','mail'
  ];
  fields= [
    'Matricule','Nom','Prenom','E-mail','Visas Participants'
  ];
  private link = environment.linklocal;

  constructor(private http: HttpClient) {}
  ngOnInit() {
  this.loadSessions();
  }

  loadSessions(): void {
    this.http.get<any[]>(this.link+"ceremonie/get/all")
      .subscribe(data => {
        this.sessions = data;
      });
  }
}

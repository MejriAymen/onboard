import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { CeremoniesComponent } from './ceremonies/ceremonies.component';
import { PagesComponent } from './pages.component';
import { AddCeremonyComponent } from './add-ceremony/add-ceremony.component';
import { NotFoundComponent } from './miscellaneous/not-found/not-found.component';
import { AddSessionComponent } from './add-session/add-session.component';
import { SessionsComponent } from './sessions/sessions.component';
import { AddFormationComponent } from './add-formation/add-formation.component';
import { FormationsComponent } from './formations/formations.component';
import { DocumentsComponent } from './documents/documents.component';
import { AddDocumentComponent } from './add-document/add-document.component';
import { CreateSessionComponent } from './create-session/create-session.component';
import { PlanningsComponent } from './plannings/plannings.component';
import { AddPresentationComponent } from './add-presentation/add-presentation.component';
import { PresentationsComponent } from './presentations/presentations.component';
import { TableaudeboardComponent } from './tableaudeboard/tableaudeboard.component';
import { ParametrageComponent } from './parametrage/parametrage.component';
const routes: Routes = [{
  path: '',
  component: PagesComponent,
  children: [
  
    {
      path: '',
      component: TableaudeboardComponent
    },
    {
      path: 'dashboard',
      component: TableaudeboardComponent
    },
    {
      path: 'tables',
      loadChildren: () => import('./tables/tables.module')
        .then(m => m.TablesModule),
    },
    {
      path: 'create-session',
      component: AddSessionComponent,
    },
    {
      path: 'sessions',
      component: SessionsComponent
    },
    {
      path: 'add-session',
      component: CreateSessionComponent
    },
    {
      path: 'plannings',
      component: PlanningsComponent
    },
    {
      path: 'miscellaneous',
      loadChildren: () => import('./miscellaneous/miscellaneous.module')
        .then(m => m.MiscellaneousModule),
    },

    {
      path: 'add-formation',
      component: AddFormationComponent
    },
    {
      path: 'formations',
      component: FormationsComponent
    },
    {
      path: 'documents',
      component: DocumentsComponent
    },
    {
      path: 'add-document',
      component: AddDocumentComponent
    },
    {
      path: 'add-ceremony',
      component: AddCeremonyComponent
    },
    {
      path: 'ceremonies',
      component: CeremoniesComponent
    },
    {
      path: 'add-presentation',
      component: AddPresentationComponent
    },
    {
      path: 'presentations',
      component: PresentationsComponent
    },
    {
      path: 'parametrage',
      component: ParametrageComponent
    },
    { path: '', redirectTo: '/dashboard', pathMatch: 'full' },

    {
      path: '**',
      component: NotFoundComponent,
    },
  ],
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PagesRoutingModule {
}

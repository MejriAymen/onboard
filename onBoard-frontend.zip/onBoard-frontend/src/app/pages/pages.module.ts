import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NbCalendarRangeModule, NbMenuModule } from '@nebular/theme';
import { NgxEchartsModule } from 'ngx-echarts';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import {
  NbActionsModule,
  NbButtonModule,
  NbCardModule,
  NbCheckboxModule,
  NbDatepickerModule, NbIconModule,
  NbInputModule,
  NbRadioModule,
  NbSelectModule,
  NbUserModule,
  NbSpinnerModule,
  NbCalendarModule,
  NbStepperModule,

} from '@nebular/theme';
import { ThemeModule } from '../@theme/theme.module';
import { PagesComponent } from './pages.component';
import { PagesRoutingModule } from './pages-routing.module';
import { MiscellaneousModule } from './miscellaneous/miscellaneous.module';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { AddSessionComponent } from './add-session/add-session.component';
import { ReactiveFormsModule } from '@angular/forms';
import { SessionsComponent } from './sessions/sessions.component';
import { AddFormationComponent } from './add-formation/add-formation.component';
import { FormationsComponent } from './formations/formations.component';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { FormsModule } from '@angular/forms';
import { AddDocumentComponent } from './add-document/add-document.component';
import { DocumentsComponent } from './documents/documents.component';
import { NbAccordionModule } from '@nebular/theme';
import { AddCeremonyComponent } from './add-ceremony/add-ceremony.component';
import { CeremoniesComponent } from './ceremonies/ceremonies.component';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { CreateSessionComponent } from './create-session/create-session.component';
import { PlanningsComponent } from './plannings/plannings.component';
import { SafranTableComponent } from '../components/safran-table/safran-table.component';
import { TableModule } from 'primeng/table';
import { AddPresentationComponent } from './add-presentation/add-presentation.component';
import { PresentationsComponent } from './presentations/presentations.component';
import { MatStepperModule } from '@angular/material/stepper';
import { NbTimepickerModule } from '@nebular/theme';
import { ParametrageComponent } from './parametrage/parametrage.component';
import { TableaudeboardComponent } from './tableaudeboard/tableaudeboard.component';
@NgModule({
  imports: [
    NgxEchartsModule,
    NgxChartsModule,
    NbTimepickerModule,
    MatStepperModule,
    TableModule,
    NbStepperModule,
    Ng2SmartTableModule,
    NbAccordionModule,
    NbIconModule,
    FormsModule,
    NgxMatSelectSearchModule,
    ReactiveFormsModule,
    PagesRoutingModule,
    ThemeModule,
    NbMenuModule,
    MiscellaneousModule,
    NbInputModule,
    NbCardModule,
    NbButtonModule,
    NbActionsModule,
    NbUserModule,
    NbCheckboxModule,
    NbRadioModule,
    NbDatepickerModule,
    NbSpinnerModule,
    NbCalendarModule,
    NbCalendarRangeModule,
    NbSelectModule,
    NgMultiSelectDropDownModule.forRoot()

  ],
  declarations: [
    SafranTableComponent,
    PagesComponent,
    LandingPageComponent,
    AddSessionComponent,
    TableaudeboardComponent,
    SessionsComponent,
    AddFormationComponent,
    FormationsComponent,
    AddDocumentComponent,
    DocumentsComponent,
    AddCeremonyComponent,
    CeremoniesComponent,
    CreateSessionComponent,
    PlanningsComponent,
    AddPresentationComponent,
    PresentationsComponent,
    ParametrageComponent  ],
  bootstrap: [PagesModule]
})
export class PagesModule {
}

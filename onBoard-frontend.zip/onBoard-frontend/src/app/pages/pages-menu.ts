import { NbMenuItem } from '@nebular/theme';
export const MENU_ITEMS: NbMenuItem[] = [

  {
    title: 'Accueil',
    icon: 'home-outline',
    link: '/pages/dashboard',
    home: true

  },
  {
    title: 'Dashboard',
    icon: 'grid-outline',
    link: '/pages/tables/dashboard',
  },
  {
    title: 'Effectif',
    icon: 'people-outline',
    children: [
      {
        title: 'Collaborateurs',
        link: '/pages/tables/smart-table',
      },
      {
        title: 'Animateurs internes',
        link: '/pages/tables/effectif-animateurs',
      },
    ],
  },
  {
    title: "Intégration générique",
    icon: 'code-outline',
    children: [

      {
        title: 'Programmer une session',
        link: '/pages/add-session',
      },
      {
        title: 'Créer un nouveau planning',
        link: '/pages/create-session',
      },

      {
        title: 'Plannings',
        link: '/pages/plannings',
      },
      {
        title: 'Sessions',
        link: '/pages/sessions',
      },
      {
        title: "Présentations",
        children: [
          {
            title: "Ajouter une présentation ",
            link: '/pages/add-presentation',
          },
          {
            title: 'Consulter les présentations',
            link: '/pages/presentations',
          },

        ]
      },
    ],

  }, 
  {
    title: 'E-learning',
    icon: 'book-outline',
    children: [
      {
        title: 'Ajouter une formation',
        link: '/pages/add-formation',
      },
      {
        title: 'Consulter les formations',
        link: '/pages/formations',
      },
    ],

  },
  {
    title: "Documents",
    icon: 'attach-2-outline',
    children: [
      {
        title: 'Ajouter un document',
        link: '/pages/add-document',
      },
      {
        title: 'Consulter les documents',
        link: '/pages/documents',
      },
    ],
  },
  {
    title: 'Evaluation',
    icon: 'star-outline',
    link: '/pages/dashboard',
  },
  {
    title: 'Paramétrage',
    icon: 'settings-outline',
    link: '/pages/parametrage'

  },
  /* {
     title: "Cérémonie d'accueil",
     icon: 'bookmark',
     children: [
       {
         title: "Programmer une cérémonie ",
         link: '/pages/add-ceremony',
       },
       {
         title: 'Consulter les cérémonies',
         link: '/pages/ceremonies',
       },
 
     ]
   }-
   ,*/

];

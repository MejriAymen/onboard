import { Component, Injectable, OnInit } from '@angular/core';
import { NbDialogService, NbToastrService } from '@nebular/theme';
import { ConfirmationDialogComponent } from '../../components/confirmation-dialog/confirmation-dialog.component';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { saveAs } from 'file-saver';
import { catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment.prod';
@Injectable({
  providedIn: 'root'
})
@Component({
  selector: 'ngx-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss']
})
export class DocumentsComponent implements OnInit {
  private link = environment.linklocal+"document/";
documents:any[];
  constructor(private toastr: NbToastrService,  private dialogService: NbDialogService,private http: HttpClient) { }

  ngOnInit(): void {
    this.loadDocuments();
  }
  loadDocuments(): void {
    this.http.get<any[]>(this.link+'get/all')
    .subscribe(data => {
      this.documents = data;
      this.documents.forEach(document => document.id = document.idDocument);

    });
  }
  openConfirmationDialog(document:any): void {
    this.dialogService
      .open(ConfirmationDialogComponent, {
        context: {
          title: 'Confirmation',
          message: 'Êtes-vous sûr de vouloir supprimer ce document ?',
        },
      })
      .onClose.subscribe((result) => {
        if (result === true) {
          this.onClickDelete(document);
        }
      });
  }

  downloadDoc(document: any): void {
    this.http.get(this.link+'download/' + document.idDocument, {
      responseType: 'blob'
    }).pipe(
      catchError((error: HttpErrorResponse) => {
        this.toastr.danger('Une erreur est survenue lors du téléchargement du document.', 'Erreur');
       // console.log(error);
        return [];
      })
    ).subscribe((response: Blob) => {
      const file = new Blob([response], { type: 'application/pdf' }); 
      saveAs(file, document.name);
    });
  }
  
  onClickDelete(document: any) {
    this.http.delete<any>(this.link+'delete/' + document.idDocument)
            .subscribe(() => {
              const index = this.documents.indexOf(document);
              if (index > -1) {
                this.documents.splice(index, 1);
              }
              this.toastr.success('Document supprimé avec succès.', 'Succès');
            }, () => {
              this.toastr.danger('Une erreur est survenue lors de la suppression du document.', 'Erreur');
            });
  }
}

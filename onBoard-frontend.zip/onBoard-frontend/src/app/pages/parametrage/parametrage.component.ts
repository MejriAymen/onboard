import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { environment } from '../../../environments/environment.prod';
import { Observable, forkJoin } from 'rxjs';

@Component({
  selector: 'ngx-parametrage',
  templateUrl: './parametrage.component.html',
  styleUrls: ['./parametrage.component.scss']
})
export class ParametrageComponent implements OnInit {
  private link = environment.linklocal;
  private societe: Observable<any> = this.http.get<any[]>(this.link + 'societes/dto');
  private uo: Observable<any> = this.http.get<any[]>(this.link + 'uniteopera/dto');
  private services: Observable<any> = this.http.get<any[]>(this.link + 'services/dto');
  data: any = {};

  settings2 = {
    actions: {
      add : false,
      edit : true,
      delete : false,
      position: 'right',
      width: '5%'
    },
    mode: 'external',
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',

    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    columns: {
      name: {
        title: 'Nom Service',
        type: 'string',

      },
      nameUO: {
        title: 'Unite Opérationnelle',
        type: 'string',

      }
    },
  };
  settings1 = {
    actions: {
      add : false,
      edit : true,
      delete : false,
      position: 'right',
      width: '5%'
    },
    mode: 'external',
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',

    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    columns: {
      name: {
        title: 'Nom Unite Opérationnelle',
        type: 'string',

      },
      nameSociete: {
        title: 'Nom Société',
        type: 'string',

      }
    },
  };

  settings = {
    actions: {
      add : false,
      edit : true,
      delete : false,
      position: 'right',
      width: '5%'
    },
    mode: 'external',
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',

    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    columns: {
      name: {
        title: 'Nom Société',
        type: 'string',

      },
      societeRang: {
        title: 'Société Rang',
        type: 'string',

      }
    },
  };

  source: LocalDataSource = new LocalDataSource();
  source1: LocalDataSource = new LocalDataSource();
  source2: LocalDataSource = new LocalDataSource();

  constructor(private http: HttpClient) {
 }

  ngOnInit(): void {
    this.fetchData();
  }

  fetchData(): void {

    forkJoin([this.societe, this.uo, this.services]).subscribe(
      ([response1, response2, response3]) => {
        this.source.load(response1);
        this.source1.load(response2);
        this.source2.load(response3);
      },
      (error) => {
        console.error('Error:', error);
      }
    );
  }

  loadSocietes(): void {
    this.http.get<any[]>(this.link + 'societes/lightdto')
      .subscribe(data => {
        this.source.load(data);
      });
  }

  loadUO(): void {
    this.http.get<any[]>(this.link + 'uniteopera/dto')
      .subscribe(data => {
        this.source1.load(data);
      });
  }

  loadServices(): void {
    this.http.get<any[]>(this.link + 'services/dto')
      .subscribe(data => {
        this.source2.load(data);
      });
  }

}

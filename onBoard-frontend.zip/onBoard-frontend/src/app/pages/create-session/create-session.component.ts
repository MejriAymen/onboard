import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { NbToastrService } from '@nebular/theme';
import { environment } from '../../../environments/environment.prod';
@Component({
  selector: 'ngx-create-session',
  templateUrl: './create-session.component.html',
  styleUrls: ['./create-session.component.scss']
})
export class CreateSessionComponent implements OnInit {
  today: Date = new Date();
  private link = environment.linklocal;
  name: string;
  submitfirstForm = false;
  firstForm: FormGroup;
  submitsecondForm = false;
  secondForm: FormGroup;
  submitthirdForm = false;
  validFour = false;
  thirdForm: FormGroup;
  fourForm:FormGroup;
  salle: any[] = [];
  selectedSalle = new FormControl();
  selectedRange = new FormControl();
  plannings: any[] = [];
  tableData: any[] = [];
  selectedRows: any[] = [];
  cols =  [
    'fullName','mail','status'
  ];
  fields= [
    'FullName','E-mail','Statut'
  ];
  dropdownSettings = {
    singleSelection: true,
    idField: 'idPlan',
    textField: 'titlePlan',
    allowSearchFilter: true,
    searchPlaceholderText: 'Chercher',
    closeDropDownOnSelection: true
  };
  selectedPlanning: number;
  @ViewChild('stepper') stepper: any;

  constructor(private fb: FormBuilder, private http: HttpClient, private datePipe: DatePipe, private toastr: NbToastrService,

  ) {
    this.loadEffectifsCollab();
    
  }
  ngOnInit(): void {
    this.fetchPlannings();
    this.firstForm = this.fb.group({
      selectedRange: ['', Validators.required]
    });
    this.secondForm = this.fb.group({
      selectedSalle: ['', Validators.required],
      selectedPlanning: ['', Validators.required]
    });

    this.thirdForm = this.fb.group({
      thirdCtrl: ['', Validators.required],
    });

  }
  fetchPlannings() {
    this.http.get<any>(this.link + 'plannings/get/all').subscribe(
      (response) => {
        this.plannings = response;
      },
      (error) => {
        console.error('Error fetching plannings:', error);
      }
    );
  }
  loadSalles(): void {
    const debutSession = this.datePipe.transform(
      this.firstForm.get('selectedRange').value.start,
      'yyyy-MM-dd'
    );
    const finSession = this.datePipe.transform(
      this.firstForm.get('selectedRange').value.end,
      'yyyy-MM-dd'
    );
    this.http.get<any[]>(this.link + 'salles/available/'+debutSession+'/'+finSession)
      .subscribe(data => {
        this.salle = data;
      });
  }
  loadEffectifsCollab(): void {
    this.http.get<any[]>(this.link + 'utilisateur/get/allmini')
      .subscribe(data => {
        this.tableData = data;
      });
  }
  onFirstSubmit() {
    this.submitfirstForm = true;
    this.firstForm.markAsDirty();
    if(!this.firstForm.valid){
      this.toastr.danger('Erreur lors de l\'ajout de la Intervall de Date', 'Erreur');
    }else{
      this.loadSalles();
    }
  }
  onSecondSubmit() {
    this.submitsecondForm = true;
    this.secondForm.markAsDirty();
  }

  onFourSubmit() {
    const debutSession = this.datePipe.transform(
      this.firstForm.get('selectedRange').value.start,
      'yyyy-MM-dd'
    );
    const finSession = this.datePipe.transform(
      this.firstForm.get('selectedRange').value.end,
      'yyyy-MM-dd'
    );
    const planSession = this.secondForm.get('selectedPlanning').value[0].idPlan;
    const salle = this.secondForm.get('selectedSalle').value;
   
    const participants = [];
    this.selectedRows.forEach(participant=>{
      participants.push({
        id : participant.id,
        fullName:participant.fullName
      });
          });
    const payload = 
      {
        debutSession: debutSession,
        finSession: finSession,
        planSession: planSession,
        salle: salle,
        sessionParticipants: participants
      }
    ;
    this.http.post(this.link + 'session/add', payload).subscribe(
      (data) => {
        this.toastr.success('Session programmée', 'Succès');
        this.submitfirstForm = false;
        this.submitsecondForm = false;
        this.submitthirdForm = false;
        this.validFour=false;
        this.secondForm.reset();
        this.firstForm.reset();
        this.selectedRows = [];
        this.loadEffectifsCollab();
        this.stepper.reset();
      },
      (error) => {
        this.toastr.danger('Erreur lors de l\'ajout de la session', 'Erreur');
       // console.log(error);
      }
    );
  }

  onThirdSubmit() {   
    this.submitthirdForm = true; 

  }

  onSelectedRowsChange(selected: any[]) {
    this.selectedRows = selected;
    if(this.selectedRows.length > 0){
      this.validFour = true;
    }else{
      this.validFour = false;
    }
  }
}
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TableaudeboardComponent } from './tableaudeboard.component';

describe('TableaudeboardComponent', () => {
  let component: TableaudeboardComponent;
  let fixture: ComponentFixture<TableaudeboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TableaudeboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TableaudeboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

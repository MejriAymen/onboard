import { Component, OnInit } from '@angular/core';
import { NbThemeService } from '@nebular/theme';

@Component({
  selector: 'ngx-tableaudeboard',
  templateUrl: './tableaudeboard.component.html',
  styleUrls: ['./tableaudeboard.component.scss']
})
export class TableaudeboardComponent implements OnInit {
  single = [
    {
      name: 'Présence',
      value: 2,
    },
    {
      name: 'absence',
      value: 1,
    },
  ];
  colorScheme: any;
  themeSubscription: any;
  constructor(private theme: NbThemeService) {

   }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NbToastrService, NbDialogService } from '@nebular/theme';
import { ConfirmationDialogComponent } from '../../components/confirmation-dialog/confirmation-dialog.component';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment.prod';
@Component({
  selector: 'ngx-add-document',
  templateUrl: './add-document.component.html',
  styleUrls: ['./add-document.component.scss']
})
export class AddDocumentComponent implements OnInit {
  documentForm: FormGroup;
  signature: boolean = true;
  fileToUpload: any;
  private link = environment.linklocal+"document/";
  constructor(
    private fb: FormBuilder,
    private toastr: NbToastrService,
    private dialogService: NbDialogService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.documentForm = this.fb.group({
      titre: ['', Validators.required],
      description: ['', Validators.required],
      file: [null, Validators.required],
      signature: [null, Validators.required]
    });
  }

  openConfirmationDialog(): void {
    this.dialogService
      .open(ConfirmationDialogComponent, {
        context: {
          title: 'Confirmation',
          message: "Êtes-vous sûr de vouloir d'ajouter ce document ?",
        },
      })
      .onClose.subscribe((result) => {
        if (result === true) {
          this.submitForm();
        }
      });
  }

  onConfirm(event: Event): void {
    event.preventDefault();

    if (this.documentForm.invalid) {
      this.toastr.warning('Tous les champs sont obligatoires', 'ATTENTION!');
      return;
    }

    this.openConfirmationDialog();
  }
  changeFile(evt) {
    this.fileToUpload = evt.target.files[0];
 }
  submitForm(): void {
    if (this.documentForm.invalid) {
      this.toastr.warning('Tous les champs sont obligatoires', 'ATTENTION!');
      return;
    }

    const formData = new FormData();
    formData.append('file', this.fileToUpload);
    formData.append('documentDesc', this.documentForm.get('description').value);
    formData.append('signature', this.documentForm.get('signature').value);
    formData.append('titleDocument', this.documentForm.get('titre').value);
    this.http.post<any>(this.link+'add', formData).subscribe(
      (response) => {
        this.toastr.success('Ajouté avec succès', 'Succès');
        this.documentForm.reset();
      },
      (error) => {
       // console.log(error);
        this.toastr.danger('Erreur lors de l\'ajout de la formation', 'Erreur');
      }
    );
  }
}

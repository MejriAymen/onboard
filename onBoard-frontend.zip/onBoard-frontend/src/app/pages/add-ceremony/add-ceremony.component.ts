import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, Validators } from '@angular/forms';
import { NbToastrService, NbDateService, NbDialogService } from '@nebular/theme';
import { NbCalendarRange } from '@nebular/theme';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { ConfirmationDialogComponent } from '../../components/confirmation-dialog/confirmation-dialog.component';
import { DatePipe } from '@angular/common';
import { environment } from '../../../environments/environment.prod';

@Component({
  selector: 'ngx-add-ceremony',
  templateUrl: './add-ceremony.component.html',
  styleUrls: ['./add-ceremony.component.scss']
})
export class AddCeremonyComponent implements OnInit {
  ceremonyForm: FormGroup;
  range: NbCalendarRange<Date>;
  selectedItems = [];
  salle: any[] = [];
  date = new Date();

  invi: { id: number, fullName: string }[];
  collaborateurs: { id: number, fullName: string }[];
  dropdownSettings: IDropdownSettings;
  private link = environment.linklocal;

  constructor(private dialogService: NbDialogService,
    private fb: FormBuilder,
    protected dateService: NbDateService<Date>,
    private toastrService: NbToastrService,
    private http: HttpClient,
    private datePipe: DatePipe,
  ) {
  }

  ngOnInit(): void {
    this.dropdownSettings = {
      singleSelection: false,
      allowSearchFilter: true,
      idField: 'id',
      textField: 'fullName',
      selectAllText: 'Selectionner tout',
      itemsShowLimit: 6,
      maxHeight: 200,
      searchPlaceholderText: 'Rechercher',
      closeDropDownOnSelection: true
    };
    this.loadSalles();
    this.loadEffectifsRec();
    this.loadEffectifsCollab();
    this.ceremonyForm = this.fb.group({
      date: ['', Validators.required],
      salle: ['', Validators.required],
      Invités: ['', Validators.required],
      Collaborateurs: ['', Validators.required],
    });
  }

  loadSalles(): void {
    this.http.get<any[]>(this.link + 'salles')
      .subscribe(data => {
        this.salle = data;
      });
  }

  loadEffectifsCollab(): void {
    this.http.get<any[]>(this.link + 'utilisateur/get/alllight')
      .subscribe(data => {

        this.invi = data;
      });
  }

  loadEffectifsRec(): void {
    this.http.get<any[]>(this.link + 'utilisateur/get/newRecs')
      .subscribe(data => {
        this.collaborateurs = data;
      });
  }

  openConfirmationDialog(): void {
    this.dialogService
      .open(ConfirmationDialogComponent, {
        context: {
          title: 'Confirmation',
          message: "Êtes-vous sûr de vopragrammer cette cérémonie ?",
        },
      })
      .onClose.subscribe((result) => {
        if (result === true) {
          this.submitForm();
        }
      });
  }
  onConfirm(event: Event): void {
    event.preventDefault();
    const values = this.ceremonyForm.value;
    if (!values.salle || !values.Invités || !values.Collaborateurs) {
      this.toastrService.warning('Veuillez remplir tous les champs avant de continuer.', 'Attention');
      return;
    }
    else {
      this.openConfirmationDialog();
    }
  }

  submitForm(): void {

    const values = this.ceremonyForm.value;
    const date = this.datePipe.transform(this.date,  'yyyy-MM-dd');
    const participants = values.Collaborateurs;
    const payload = 
    {
      debutSession: date,
      finSession: date,
      planSession: 0,
      salle: values.salle,
      participants: []
    };
  this.http.post(this.link + 'session/add', payload).subscribe(
    (data) => {
      this.toastrService.success('La cérémonie est plannifié avec succès', 'Succès');
    this.ceremonyForm.reset();
    },
    (error) => {
      this.toastrService.danger('Erreur lors de l\'ajout de la cérémonie', 'Erreur');
      //console.log(error);
    }
  );
    
  }
}
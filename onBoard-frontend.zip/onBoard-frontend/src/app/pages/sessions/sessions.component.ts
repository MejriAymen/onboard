import { Component, OnInit ,ElementRef} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
import { environment } from '../../../environments/environment.prod';
import * as XLSX from 'xlsx';
@Component({
  selector: 'ngx-sessions',
  templateUrl: './sessions.component.html',
  styleUrls: ['./sessions.component.scss']
})
export class SessionsComponent implements OnInit {
  pdfs: any[];
  htmlContent: any;
  sessions: any[];
  sessionparticipant: any[];
  selectedRows: any[] = [];
  cols =  [
    'matricule','nom','prenom','mail'
  ];
  fields= [
    'Matricule','Nom','Prenom','E-mail','Visas Participants'
  ];
  private link = environment.linklocal;

  constructor(private http: HttpClient, private sanitizer: DomSanitizer,private elementRef: ElementRef) {}
  ngOnInit() {
  this.loadSessions();
  }

  loadSessions(): void {
    this.http.get<any[]>(this.link+"session/get/all")
      .subscribe(data => {
        this.sessions = data;
        console.log(data);
      });
  }
  getIntegStautText(value): string {
    if (value === 'NOUVEAU') {
     return 'NOUVEAU';
   } else if (value === 'REPORTE') {
     return 'Reporté';
   } else if (value === 'ABSENT') {
     return 'Absent';
   } else if (value === 'FIGE') {
     return 'Figé';
   } else if (value === 'INVITE') {
     return 'invité';
   } else{
     return 'Présent';
   }
 }

 getIntegStautStatus(value): string {
   if (value === 'NOUVEAU') {
     return 'basic';
   } else if (value === 'REPORTE' || value === 'ABSENT') {
     return 'warning';
   } else if (value === 'FIGE') {
     return 'danger';
   } else {
     return 'success';
   }
 }

 downloadExcel(data): void  {
  const nomDoc = "Session N° "+ data.idSession +".xlsx";
  const wb: XLSX.WorkBook = XLSX.utils.book_new();
  const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet([["Session N° "+ data.idSession]]); 
  XLSX.utils.sheet_add_aoa(ws, [[ data.debutSession +" à "+ data.finSession]], { origin: -1 });
  XLSX.utils.sheet_add_aoa(ws, [[ data.salle.name]], { origin: -1 });
  XLSX.utils.sheet_add_aoa(ws, [], { origin: -1 });
  XLSX.utils.sheet_add_aoa(ws, [], { origin: -1 });
  XLSX.utils.sheet_add_aoa(ws, [["Nom", "Prénom","E-mail", "Statue"]], { origin: -1 });
  data.participants.forEach((p) => {
    const rowData = [p.participant.nom, p.participant.prenom, p.participant.mail,p.statue];
    XLSX.utils.sheet_add_aoa(ws, [rowData], { origin: -1 });
  });

  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  XLSX.writeFile(wb, nomDoc);
  }
}
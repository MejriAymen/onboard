import { Component, OnInit } from '@angular/core';
import { NbDialogService, NbToastrService, NbWindowService } from '@nebular/theme';
import { ConfirmationDialogComponent } from '../../components/confirmation-dialog/confirmation-dialog.component';
import { PresentationEditComponent } from '../../components/presentation-edit/presentation-edit.component';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { saveAs } from 'file-saver';
import { environment } from '../../../environments/environment.prod';

@Component({
  selector: 'ngx-presentations',
  templateUrl: './presentations.component.html',
  styleUrls: ['./presentations.component.scss']
})
export class PresentationsComponent implements OnInit {
  presentations: any[];
  private link = environment.linklocal+"presentation/";

  constructor(private toastr: NbToastrService,private http: HttpClient,private dialogService: NbDialogService,private windowService: NbWindowService) { }

  ngOnInit(): void {
    this.loadPresentations();
  }
  loadPresentations(): void {
    this.http.get<any[]>(this.link+'get/all')
    .subscribe(data => {
      this.presentations = data;
      this.presentations.forEach(presentation => presentation.id = presentation.idPresentation);

    });
  }
  openConfirmationDialog(presentation:any): void {
    this.dialogService
      .open(ConfirmationDialogComponent, {
        context: {
          title: 'Confirmation',
          message: 'Êtes-vous sûr de vouloir supprimer cette présentation ?',
        },
      })
      .onClose.subscribe((result) => {
        if (result === true) {
          this.onClickDelete(presentation);
        }
      });
  }
  download(presentation: any): void {
    this.http.get(this.link+'download/' + presentation.idPresentation, {
      responseType: 'blob'
    }).pipe(
      catchError((error: HttpErrorResponse) => {
        this.toastr.danger('Une erreur est survenue lors du téléchargement du document.', 'Erreur');
       // console.log(error);
        return [];
      })
    ).subscribe((response: Blob) => {
      const file = new Blob([response], ); 
      saveAs(file, presentation.presentation);
    });
  }
  

  onClickDelete(presentation: any): void {
    this.http.delete<any>(this.link+'delete/' + presentation.idPresentation)
    .subscribe(() => {
      const index = this.presentations.indexOf(presentation);
      if (index > -1) {
        this.presentations.splice(index, 1);
      }
      this.toastr.success('Document supprimé avec succès.', 'Succès');
    }, () => {
      this.toastr.danger('Une erreur est survenue lors de la suppression du document.', 'Erreur');
    });
}
    
  
  openFileUploadWindow(presentation:any) {
    this.windowService.open(
      PresentationEditComponent, // Component to be displayed in the modal window
      { title: 'Veuillez télécharger la nouvelle présentation', windowClass: 'file-upload-modal',context:{presentation} } // Configuration for the modal window
    );
  }
}


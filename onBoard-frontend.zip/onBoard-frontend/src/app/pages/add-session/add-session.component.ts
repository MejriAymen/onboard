import { Component, OnInit} from '@angular/core';
import { FormBuilder, FormGroup, FormsModule } from '@angular/forms';
import { FormArray} from '@angular/forms';
import { NbToastrService, NbDateService} from '@nebular/theme';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Plannings } from '../../models/plannings';
import { environment } from '../../../environments/environment.prod';
@Component({
  selector: 'ngx-add-session',
  templateUrl: './add-session.component.html',
  styleUrls: ['./add-session.component.scss']
})
export class AddSessionComponent implements OnInit {
  private link = environment.linklocal;
  sessionForm: FormGroup;
  dropdownList = [];
  selectedItems = [];
  interlocuteur: { id: number, fullName: string }[];
  dropdownSettings : IDropdownSettings;
  planningForm: FormGroup;
  savedPlanning: Plannings;
fields: any[] ;

  constructor(
    private fb: FormBuilder,
    protected dateService: NbDateService<Date>,
    private toastrService: NbToastrService,
    private http: HttpClient
    ) {
   
  }
  
  ngOnInit(): void {
    this.planningForm = this.fb.group({
      titlePlan:'',
      fields:[]
    });
    this.loadinterlocuteur();
    this.sessionForm = this.fb.group({});
    this.dropdownSettings= {
      singleSelection: false,
      idField: 'id',
      textField: 'fullName',
      itemsShowLimit: 3,
      allowSearchFilter: true,
      maxHeight:200,
      searchPlaceholderText:'Chercher un animateur interne',
      closeDropDownOnSelection: true
    };
    this.sessionForm = this.fb.group({
      sessionDays: this.fb.array([this.createDay()])
    });
  }
  
  loadinterlocuteur(): void {
    this.http.get<any[]>(this.link + 'utilisateur/get/animatorslight')
      .subscribe(data => {
        this.interlocuteur = data;
      });
  }

  createDay(): FormGroup {
    return this.fb.group({
      fields: this.fb.array([
        this.createField(),
      ]),
      pauses: this.fb.array([
        this.createPause()
      ]),


    });
  }
  createPause(): FormGroup {
    return this.fb.group({
      pause1From: '',
      pause1To: '',
      pause2From: '',
      pause2To: '',
      pauseDejFrom: '',
      pauseDejTo: '',

    });
  }
  createField(): FormGroup {
    return this.fb.group({
      fieldFrom: '',
      fieldTo: '',
      presentation: '',
      interlocuteur: ''
    });
  }

  get sessionDays(): FormArray {
    return this.sessionForm.get('sessionDays') as FormArray;
  }

  addDay(): void {
    this.sessionDays.push(this.createDay());
  }

  removeDay(index: number): void {
    this.sessionDays.removeAt(index);
  }

  addField(dayFields: FormArray): void {
    dayFields.push(this.createField());
  }

  removeField(dayFields: FormArray, index: number): void {
    dayFields.removeAt(index);
  }
  
  
  onConfirm(event: Event): void {

    event.preventDefault();
    const values = this.sessionForm.value;
    let hasEmptyField = false;
    for (let day of values.sessionDays) {
      for (let field of day.fields) {
        if (!field.fieldFrom || !field.fieldTo || !field.presentation  ) {
          hasEmptyField = true;
          break;
        }
   
      }
    }
    if (this.planningForm.value.titlePlan===''){
      hasEmptyField = true;
      
    }
    if (hasEmptyField) {
      this.toastrService.warning('Veuillez remplir tous les champs avant de continuer.', 'Attention');
      return;
    }

    if (this.sessionDays.length === 0) {
      this.toastrService.warning('Veuillez ajouter au moins un jour à la session avant de continuer.', 'Attention');
      return;
    }
    this.submitForm();

    
    
  }

  prepareData(data: any): any {
    this.fields = []; // initialize the array before the loop
    for (let i = 0; i < data.length; i++) {
      const flattenedArray = [].concat(...data[i].fields); // merge the nested arrays
      const pauseFormGroup =data[i].pauses as FormGroup;
      const pause1From = pauseFormGroup[0]['pause1From'];
      const pause1To = pauseFormGroup[0]['pause1To'];
      const pause2From = pauseFormGroup[0]['pause2From'];
      const pause2To = pauseFormGroup[0]['pause2To'];
      const pauseDejFrom = pauseFormGroup[0]['pauseDejFrom'];
      const pauseDejTo = pauseFormGroup[0]['pauseDejTo'];
      const pause1Array = {
        day : i+1,
        fieldFrom: pause1From,
        fieldTo: pause1To,
        presentation: 'pause'
       
      }
      const pause2Array = {
        day : i+1,
        fieldFrom: pause2From,
        fieldTo: pause2To,
        presentation: 'pause'
      }
      const pauseDejArray = {
        day : i+1,
        fieldFrom: pauseDejFrom,
        fieldTo: pauseDejTo,
        presentation: 'dejeuner'
       
      }
      const modifiedArray = flattenedArray.map((field: any) => {
        const interlocuteurs = field.interlocuteur;
        const interlocuteurNames = [];
        for (let j = 0; j < interlocuteurs.length; j++) {
          const interlocuteur = interlocuteurs[j];
       
            interlocuteurNames.push(interlocuteur.fullName);
         
        }
        return {
          day: i + 1, // add the "day" parameter with the value of i + 1
          fieldFrom: field.fieldFrom,
          fieldTo: field.fieldTo,
          interlocuteurs: field.interlocuteur,
          presentation: field.presentation,
        };
      });
      this.fields.push(...modifiedArray); // spread the modified array into the fields array
      if(pause1Array.fieldFrom&&pause1Array.fieldTo){this.fields.push(pause1Array);}
      if(pause2Array.fieldFrom&&pause2Array.fieldTo){ this.fields.push(pause2Array);}
      if(pauseDejArray.fieldFrom&&pauseDejArray.fieldTo){this.fields.push(pauseDejArray);}
     
    }
    return this.fields; 
  }
  
  submitForm(): void {
    this.fields=this.prepareData(this.sessionDays.value);
    const planning = {
    titlePlan: this.planningForm.value.titlePlan,
    fields: this.fields
    };
    this.http.post<Plannings>(this.link+'plannings/add',planning).subscribe(
      (savedPlanning) => {
        this.savedPlanning=savedPlanning;
        this.toastrService.success('Ajouté avec succès','Succès');
        this.sessionForm.reset();

      },
      (error) => {
        this.toastrService.danger(error, 'Erreur');
      }
    );    
  }
}

import { Component, OnInit } from '@angular/core';
import { NbToastrService,NbDialogService, NbWindowService} from '@nebular/theme';
import { ConfirmationDialogComponent } from '../../components/confirmation-dialog/confirmation-dialog.component';
import { HttpClient } from '@angular/common/http';
import { FormationEditComponent } from '../../components/formation-edit/formation-edit.component';
import { environment } from '../../../environments/environment.prod';
import { ListCertifComponent } from '../../components/List-certif/List-certif.component';

@Component({
  selector: 'ngx-formations',
  templateUrl: './formations.component.html',
  styleUrls: ['./formations.component.scss']
})
export class FormationsComponent implements OnInit {
  private link = environment.linklocal+"formations/";
  formations: any[];
  selectedFormation: string = '';
  filteredFormations: any[];
  isRecommended: boolean;
  isRequired: boolean;

  constructor(private toastr: NbToastrService, private dialogService: NbDialogService,private http: HttpClient,private windowService: NbWindowService) { }

  ngOnInit(): void {
    this.loadFormations();

  }
  loadFormations(): void {
    this.http.get<any[]>(this.link+'get/all')
    .subscribe(data => {
      this.formations = data;
      this.formations.forEach(formation => {
        formation.id = formation.idFormation;
      }
        );
      this.filteredFormations=this.formations;
    });
  }

  filterFormations(searchTerm: string ='') {
    this.filteredFormations = this.formations.filter(formation => {
      const matchesRecommended = !this.isRecommended || !formation.obligatory;
      const matchesRequired = !this.isRequired || formation.obligatory;
      const matchesTitle = !searchTerm || formation.titleForm.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesDepartment = formation.departement.toLowerCase().includes(searchTerm.toLowerCase());
      return (matchesRecommended && matchesRequired) && (matchesTitle || matchesDepartment);      
    });
  }
  openConfirmationDialog(formation: any): void {
    this.dialogService
      .open(ConfirmationDialogComponent, {
        context: {
          title: 'Confirmation',
          message: 'Êtes-vous sûr de vouloir supprimer cette formation ?',
        },
      })
      .onClose.subscribe((confirmed: boolean) => {
        if (confirmed) {
          this.http.delete<any>(this.link+'delete/' + formation.id)
            .subscribe(() => {
              const index = this.formations.indexOf(formation);
              if (index > -1) {
                this.formations.splice(index, 1);
              }
              this.toastr.success('Formation supprimée avec succès.', 'Succès');
            }, () => {
              this.toastr.danger('Une erreur est survenue lors de la suppression de la formation.', 'Erreur');
            });
        }
      });
  }
  onClickGo(link: string) {
    window.open(link, '_blank');
  }

  onClickEdit(formation: any)  {
    this.windowService.open(
      FormationEditComponent,
      { title: 'Veuillez modifier la formation', windowClass: 'file-upload-modal', context: { formation: formation } } // Configuration for the modal window
    );
    
  }

  onClickListCertifs(formation: any)  {
    this.windowService.open(
      ListCertifComponent,
      { title: 'Liste des certifications', windowClass: 'file-upload-modal', context: { formation: formation } } // Configuration for the modal window
    );
    
  }
 
}

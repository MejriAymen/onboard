import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { NbToastrService, NbDialogService } from '@nebular/theme';
import { ConfirmationDialogComponent } from '../../components/confirmation-dialog/confirmation-dialog.component';
import { environment } from '../../../environments/environment.prod';

interface Formation {
  titleForm: string;
  description: string;
  departement: string;
  link: string;
  imageFormation: string;
  obligatoiry: boolean;
}
@Component({
  selector: 'ngx-add-formation',
  templateUrl: './add-formation.component.html',
  styleUrls: ['./add-formation.component.scss']
})
export class AddFormationComponent implements OnInit {
  fileToUpload: any;

  departements: string[] = [];
  SensibilisationForm: FormGroup;
  obligatoire: boolean = false;
  generique: boolean = true;
  private link = environment.linklocal;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private toastr: NbToastrService,
    private dialogService: NbDialogService
  ) {}

  ngOnInit(): void {
    this.http.get<any[]>(this.link + 'services/dto')
      .subscribe(data => {
        this.departements = data;
      });

    this.SensibilisationForm = this.fb.group({
      titre: ['', Validators.required],
      description: ['', Validators.compose([
        Validators.required,
        this.customValidator()
      ])],
      departement: [null],
      lien: ['', Validators.required],
      image: ['', Validators.required],
      obligatoire: [false, Validators.required],
      generique: [true, Validators.required]

    });
  }

  openConfirmationDialog(): void {
    this.dialogService
      .open(ConfirmationDialogComponent, {
        context: {
          title: 'Confirmation',
          message: "Êtes-vous sûr d'ajouter cette formation ?",
        },
      })
      .onClose.subscribe((result) => {
        if (result === true) {
          this.submitForm();
        }
      });
  }

  customValidator() {
    return (control: AbstractControl): {[key: string]: any} | null => {
      const description = control.value;
      if (!description) {
        return { 'FieldsRequired': true };
      }
      return null;
    };
  }
  changeFile(evt) {
    this.fileToUpload = evt.target.files[0];
  }
  onConfirm(event: Event): void {
    event.preventDefault();

    if (this.SensibilisationForm.invalid) {
      this.toastr.warning('Tous les champs sont obligatoires', 'ATTENTION!');
      return;
    }

    this.openConfirmationDialog();
  }

  submitForm(): void {
    const imageFile = this.fileToUpload;
    const formData = new FormData()
    if (imageFile) {
      formData.append('imageFormation', imageFile);
    }
    else{
      this.toastr.warning("L'image est obligatoire", "ATTENTION!");
    }
    formData.append('titleFormation', this.SensibilisationForm.get('titre').value);
    formData.append('description', this.SensibilisationForm.get('description').value);
    if(this.SensibilisationForm.get('departement').value != null){
      formData.append('departement', this.SensibilisationForm.get('departement').value);
    }
    formData.append('link', this.SensibilisationForm.get('lien').value);
    formData.append('isObligatory', this.SensibilisationForm.get('obligatoire').value);
    formData.append('isGeneric', this.SensibilisationForm.get('generique').value);

    this.http.post<Formation>(this.link+'formations/add', formData).subscribe(
      (savedFormation) => {
        this. saveImageWithNewName(imageFile,savedFormation.imageFormation);
        this.toastr.success('Ajouté avec succès','Succès');
        this.SensibilisationForm.reset();
      },
      (error) => {
       // console.log(error);
        this.toastr.danger('Erreur lors de l\'ajout de la formation', 'Erreur');
      }
    );
  }
  
  saveImageWithNewName(file: File, newFileName: string) {
    const reader = new FileReader();
    reader.onload = () => {
      // Perform any additional processing or API calls here, such as uploading the image to a server
      //console.log('Image saved with new name:', newFileName);
    };
    reader.readAsDataURL(file);
  }


}

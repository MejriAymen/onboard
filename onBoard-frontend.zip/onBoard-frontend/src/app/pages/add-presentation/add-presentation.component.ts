import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { NbToastrService, NbDialogService } from '@nebular/theme';
import { ConfirmationDialogComponent } from '../../components/confirmation-dialog/confirmation-dialog.component';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment.prod';
@Component({
  selector: 'ngx-add-presentation',
  templateUrl: './add-presentation.component.html',
  styleUrls: ['./add-presentation.component.scss']
})
export class AddPresentationComponent implements OnInit {
  private link = environment.linklocal+"presentation/";
  presentationForm:FormGroup;
  fileToUpload: any;
  constructor(private fb: FormBuilder,private toastr: NbToastrService,  private dialogService: NbDialogService,    private http: HttpClient
    )
  {}
  
    ngOnInit(): void {
      this.presentationForm = this.fb.group({
        
      });
      this.presentationForm = this.fb.group({
        titre: ['', Validators.required],
        description: ['', Validators.required],
        fichier: [null, Validators.required],
      });
    }
    openConfirmationDialog(): void {
      this.dialogService
        .open(ConfirmationDialogComponent, {
          context: {
            title: 'Confirmation',
            message: "Êtes-vous sûr de vouloir d'ajouter ce document ?",
          },
        })
        .onClose.subscribe((result) => {
          if (result === true) {
            this.submitForm();
          }
        });
    }
    onConfirm(event: Event): void {
      event.preventDefault();
    
      if (this.presentationForm.invalid) {
        this.toastr.warning('Tous les champs sont obligatoires','ATTENTION!');
        return;
      }
    
      this.openConfirmationDialog();
    }
    changeFile(evt) {
      this.fileToUpload = evt.target.files[0];
   }
    submitForm(): void {
      if (this.presentationForm.invalid) {
        this.toastr.warning('Tous les champs sont obligatoires', 'ATTENTION!');
        return;
      }
  
      const formData = new FormData();
      formData.append('file', this.fileToUpload);
      formData.append('presentationDesc', this.presentationForm.get('description').value);
      formData.append('titlePresentation', this.presentationForm.get('titre').value);
      this.http.post<any>(this.link+'add', formData).subscribe(
        () => {
          this.toastr.success('Ajouté avec succès', 'Succès');
          this.presentationForm.reset();
        },
        (error) => {
         // console.log(error);
          this.toastr.danger('Erreur lors de l\'ajout de la formation', 'Erreur');
        }
      );
    }
     
    }
  
  
import { Component, OnInit, TemplateRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { LocalDataSource } from 'ng2-smart-table';
import { NbToastrService, NbWindowRef, NbWindowService } from '@nebular/theme';
import { DataService } from '../../../services/data.service';
import { environment } from '../../../../environments/environment.prod';
import { DatePipe } from '@angular/common';
import { UtilisateurService } from '../../../services/utilisateur.service';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
@Component({
  selector: 'ngx-effectif-animateurs',
  templateUrl: './effectif-animateurs.component.html',
  styleUrls: ['./effectif-animateurs.component.scss']
})
export class EffectifAnimateursComponent implements OnInit {
  formData: any = {};
  dropdownSettings: IDropdownSettings;

  settings = {
    mode: 'external',
    actions: {
      edit: false
    },
    add: {
      addButtonContent: '<i class="nb-plus"></i>',
      createButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    columns: {
      nom: {
        title: 'Nom',
        type: 'string',
      },
      prenom: {
        title: 'Prénom',
        type: 'string',

      },
      mail: {
        title: 'E-mail',
        type: 'string',
      },
      poste: {
        title: 'Poste',
        type: 'string',
        valuePrepareFunction: (cell, row) => {
          if (row.poste != null) {
            return row.poste.name;
          }
        }
      },
      societe: {
        title: 'Société',
        type: 'string',
        valuePrepareFunction: (cell, row) => {
          if (row.societe != null) {
            return row.societe.name;
          }
        }
      },
      uo: {
        title: 'Unite Opérationnelle',
        type: 'string',
        valuePrepareFunction: (cell, row) => {
          if (row.uo != null) {
            return row.uo.name;
          }
        }
      },
      service: {
        title: 'Service',
        type: 'string',
        valuePrepareFunction: (cell, row) => {
          if (row.service != null) {
            return row.service.name;
          }
        }
      },
      manager: {
        title: 'Manager',
        type: 'string',
      }
    },
  };
  dropdownOptions: { id: number, fullName: string }[];
  selectedOptions: { id: number, fullName: string }[];
  dataAnimator: number[];
  optionsMap: any = {};
  data: any = {};
  source: LocalDataSource = new LocalDataSource();
  windowRef: NbWindowRef;
  private link = environment.linklocal;
  constructor(private http: HttpClient,
    private windowService: NbWindowService,
    private dataService: DataService,
    private utlisateurservice: UtilisateurService,
    private toasterService: NbToastrService,
    private datePipe: DatePipe) {
  }

  loadEffectifsCollab(): void {
    this.http.get<any[]>(this.link + 'utilisateur/get/collab/all')
      .subscribe(data => {
        this.dropdownOptions = data;
        this.selectedOptions = [];
      });
  }

  loadEffectifs(): void {
    this.http.get<any[]>(this.link + 'utilisateur/get/animator/all')
      .subscribe(data => {
        this.data = data.map(item => {
          item.entree = this.datePipe.transform(item.entree, 'yyyy-MM-dd');
          return item;
        });

        this.source.load(this.data); 
      });
  }

  rowVar(event: any): void {
    const data = event.data;
    this.dataService.formData = data;
  }

  ngOnInit(): void {
    this.loadEffectifsCollab();
    this.loadEffectifs();
    this.dropdownSettings = {
      singleSelection: false,
      allowSearchFilter: true,
      idField: 'id',
      textField: 'fullName',
      selectAllText: 'Selectionner tout',
      itemsShowLimit: 6,
      maxHeight: 200,
      searchPlaceholderText: 'Rechercher',
      closeDropDownOnSelection: false
    };
  }

  // is animator egale false no delete
  deleteAnimator(event) {
    this.utlisateurservice.deleteAnimator(event.data.id).subscribe(data => {
      this.toasterService.success("Suppression avec succés", "Succés");
      this.loadEffectifs();
      this.loadEffectifsCollab();
    },
      error => {
        this.toasterService.danger("Merci de contacter le service IT", "ERROR");
      });
  }

  addAnimators() {
    this.dataAnimator = [];
    this.selectedOptions.forEach(opt => {
      this.dataAnimator.push(opt.id);
    });
    this.utlisateurservice.addAnimators(this.dataAnimator).subscribe(data => {
      this.loadEffectifs();
      this.loadEffectifsCollab();
      this.toasterService.success("succés", "Succés");
      if (this.windowRef) {
        this.windowRef.close(); // Close the modal using the window reference
      }
    },
      error => {
        console.log(error);
        this.toasterService.danger("Merci de contacter le service IT", "ERROR");
      });
  }

  openmodal(dialog: TemplateRef<any>) {
    this.windowRef = this.windowService.open(dialog);
  }
}

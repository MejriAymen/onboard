import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EffectifAnimateursComponent } from './effectif-animateurs.component';

describe('EffectifAnimateursComponent', () => {
  let component: EffectifAnimateursComponent;
  let fixture: ComponentFixture<EffectifAnimateursComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EffectifAnimateursComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EffectifAnimateursComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

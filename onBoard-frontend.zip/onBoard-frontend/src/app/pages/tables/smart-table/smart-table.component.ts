import { Component, ElementRef, TemplateRef, ViewChild } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpClient } from '@angular/common/http';
import { NbDialogService, NbGlobalPhysicalPosition, NbToastrService, NbWindowRef, NbWindowService } from '@nebular/theme';
import { WindowFormComponent } from '../../../window-form/window-form.component';
import { DataService } from '../../../services/data.service';
import { environment } from '../../../../environments/environment.prod';
import { DatePipe } from '@angular/common';
import { UtilisateurService } from '../../../services/utilisateur.service';
import { RoleServiceService } from '../../../services/role-service.service';
import { utilisateur } from '../../../models/utilisateur';
@Component({
  selector: 'ngx-smart-table',
  templateUrl: './smart-table.component.html',
  styleUrls: ['./smart-table.component.scss'],
})
export class SmartTableComponent {
  private link = environment.linklocal;
  dropdownSettings = {
    singleSelection: true,
    idField: 'id',
    textField: 'name',
    allowSearchFilter: true,
    maxHeight: 300,
    searchPlaceholderText: 'Chercher',
    closeDropDownOnSelection: true
  };
  disabledUO = true;
  disabledSERVICE = true;
  managers = [];
  searchname: string;
  Societes: any;
  UO: any;
  Services: any;
  postes: any;
  data: utilisateur[] = [];
  user: any = {};
  role: any;
  username: string;
  motDePasseC: string;
  prenom: string;
  nom: string;
  mail: string;
  login: string;
  manager: string[] = [];
  index: number;
  utilisateurmodel: utilisateur;
  listRole: { id: number, role: string }[] = [];
  settings = {
    actions: {
      add: true,
      edit: false,
      delete: true,
    },
    mode: 'external',
    add: {
      addButtonContent: '<i class="nb-plus"></i>',
      createButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',

    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    columns: {
      matricule: {
        title: 'Matricule',
        type: 'number',
        editable: false,
      },
      nom: {
        title: 'Nom',
        type: 'string',
      },
      prenom: {
        title: 'Prénom',
        type: 'string',

      },  
      mail: {
        title: 'E-mail',
        type: 'string',
      },
      poste: {
        title: 'Poste',
        type: 'string',
        valuePrepareFunction: (cell, row) => {
          if (row.poste != null) {
            return row.poste.name;
          }
        }
      },
      societe: {
        title: 'Société',
        type: 'string',
        valuePrepareFunction: (cell, row) => {
          if (row.societe != null) {
            return row.societe.name;
          }
        }
      },
      uo: {
        title: 'Unite Opérationnelle',
        type: 'string',
        valuePrepareFunction: (cell, row) => {
          if (row.uo != null) {
            return row.uo.name;
          }
        }
      },
      service: {
        title: 'Service',
        type: 'string',
        valuePrepareFunction: (cell, row) => {
          if (row.service != null) {
            return row.service.name;
          }
        }
      },
      manager: {
        title: 'Manager',
        type: 'string',
      },
    },



  };
  settings1 = {
    mode: 'external',
    actions: {
      add: false,
      edit: false,
      delete: true,
      position: 'right',
    },
    add: {
      addButtonContent: '<i class="nb-plus"></i>',
      createButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',

    },
    delete: {
      deleteButtonContent: '<i class="nb-plus"></i>',
      confirmDelete: true,
    },
    columns: {
      matricule: {
        title: 'Matricule',
        type: 'number',
        editable: false,
      },
      nom: {
        title: 'Nom',
        type: 'string',
      },
      prenom: {
        title: 'Prénom',
        type: 'string',

      },
      mail: {
        title: 'E-mail',
        type: 'string',
      },
    },



  };
  source: LocalDataSource = new LocalDataSource();
  source1: LocalDataSource;
  loading: boolean = false;
  constructor(private http: HttpClient,
    private windowService: NbWindowService,
    private dataService: DataService,
    private utlisateurservice: UtilisateurService,
    private datePipe: DatePipe,
    private toasterService: NbToastrService,
    private dialogservice: NbDialogService,
    private roleService: RoleServiceService
  ) {

  }
  ngOnInit(): void {
    this.loadEffectifs();
    this.loadServices();
    this.loadSocietes();
    this.loadPosts();
    this.ListRole();
  }
  rowVar(event: any): void {

    const data = event.data;
    this.dataService.formData = data;

  }
  //delete execution :
  onDelete(event) {
    this.utlisateurservice.deleteUtilisateur(event.data.id).subscribe(data => {
      this.toasterService.success("Suppression avec succés", "Succés");
      this.loadEffectifs();
    },
      error => {
        this.toasterService.danger("Merci de contacter le service IT", "ERROR");
      });
  }

  onEdit(event): void {
    this.windowService.open(WindowFormComponent, {
      title: 'Modifier collaborateur',
      context: {
        employee: event.data, // pass the employee data to the window
      },
    }).onClose.subscribe(newData => {
      if (newData) {
        // update the employee data in the table
        event.confirm.resolve(newData);
      } else {
        event.confirm.reject();
      }
    });
  }

  loadEffectifs(): void {
    this.http.get<any[]>(this.link + "utilisateur/" + 'get/all')
      .subscribe(data => {
        this.managers = [];
        this.data = data.map(item => {
          // Format the "entree" value to the required format
          item.entree = this.datePipe.transform(item.entree, 'yyyy-MM-dd');
          return item;
        });
        this.data.forEach((collab: utilisateur) => {
          if (collab.mail != null) {
            this.managers.push(collab.mail);
          };
        }
        );
        this.source.load(this.data); // Assign the formatted data to the LocalDataSource
      });
  }

  openmodal(dialog: TemplateRef<any>, event) {
    this.windowService.open(dialog);
  }

  //search utilisateur :
  Search() {
    this.loading = true
    this.source1 = new LocalDataSource();
    this.utlisateurservice.searchuser(this.searchname).subscribe(data => {
      this.source1 = data;
      this.loading = false
    }, error => {
      this.loading = false
    })
  }


  delete(win: NbWindowRef, event, dialogadd: TemplateRef<any>) {
    this.username = event.data.login;
    this.mail = event.data.mail;
    this.nom = event.data.nom;
    this.prenom = event.data.prenom;
    this.user = event.data;
    this.utilisateurmodel = new utilisateur();
    this.dialogservice.open(dialogadd);
  }

  saveuser(win: NbWindowRef) {
    const roleU = this.listRole.find(variable => variable.id == this.role);
    this.user.matricule = this.utilisateurmodel.matricule;
    this.user.poste = this.utilisateurmodel.poste[0];
    this.user.service = this.utilisateurmodel.service[0];
    this.user.societe = this.utilisateurmodel.societe[0];
    this.user.uo = this.utilisateurmodel.uo[0];
    this.user.manager = this.utilisateurmodel.manager;
    this.user.actif = true;

    this.utlisateurservice.addusers(this.user, this.nom, this.prenom, this.username, this.mail, roleU).subscribe(data => {
      this.showtoasts("utilisateur ajouté avec succée", "Succée", "success", 3000)
      this.loadEffectifs();
    }, error => {
      if (error.status == 409)
        this.showtoasts("cet utilisateur existe deja , Merci de verivier le nom d'utilisateur", "Error", "danger", 3000);
      else
        this.showtoasts("Error", "Error", "danger", 3000);
    });

    win.close()
  }

  ListRole() {
    this.roleService.getallRole().subscribe(data => {
      data.forEach(element => {
        this.listRole.push({
          'id': element.id,
          'role': element.intitule
        });
      });
    }, error => console.log(error))
  }


  private showtoasts(body: string, title: string, type: string, duration: number) {
    const config = {
      status: type,
      destroyByClick: true,

      duration: duration,
      hasIcon: false,
      position: NbGlobalPhysicalPosition.TOP_RIGHT,
      preventDuplicates: false,
    };
    this.index += 1;
    this.toasterService.show(
      body,
      title,
      config);
  }


  onEdite(event, UpdateForm) {
    this.utilisateurmodel = new utilisateur();
    this.dialogservice.open(UpdateForm);
    this.parseDataUser(event.data);
  }


  parseDataUser(event): void {
    this.utilisateurmodel.id = event.id;
    this.utilisateurmodel.nom = event.nom;
    this.utilisateurmodel.prenom = event.prenom;
    this.utilisateurmodel.poste = [event.poste];
    this.utilisateurmodel.matricule = event.matricule;
    this.utilisateurmodel.mail = event.mail;
    this.utilisateurmodel.manager = event.manager;
    this.utilisateurmodel.uo = [event.uo];
    this.utilisateurmodel.societe = [event.societe];
    this.utilisateurmodel.service = [event.service];


  }

  EditUtilisateur(win2: NbWindowRef) {
    this.utilisateurmodel.manager = Array.isArray(this.utilisateurmodel.manager) ?this.utilisateurmodel.manager[0] : this.utilisateurmodel.manager;
    this.utilisateurmodel.uo = Array.isArray(this.utilisateurmodel?.uo) ? this.utilisateurmodel?.uo[0]: this.utilisateurmodel?.uo;
    this.utilisateurmodel.societe = Array.isArray(this.utilisateurmodel?.societe) ? this.utilisateurmodel?.societe[0]: this.utilisateurmodel?.societe;
    this.utilisateurmodel.service = Array.isArray(this.utilisateurmodel?.service) ? this.utilisateurmodel?.service[0]: this.utilisateurmodel?.service;
    this.utilisateurmodel.poste = Array.isArray(this.utilisateurmodel.poste) ? this.utilisateurmodel?.poste[0]: this.utilisateurmodel?.poste;


    this.utlisateurservice.update(this.utilisateurmodel).subscribe(data => {

      this.showtoasts("Modification avec succés", "Succés", "success", 2000)
      this.loadEffectifs();
      win2.close();
    },
      error => {
        this.showtoasts("Merci de contacter le service IT", "ERROR", "danger", 2000)
      });

  }
  loadSocietes(): void {
    this.http.get<any[]>(this.link + 'societes/dto')
      .subscribe(data => {
        this.Societes = data;
      });
  }
  loadPosts(): void {
    this.http.get<any[]>(this.link + 'postes')
      .subscribe(data => {
        this.postes = data;
      });
  }

  loadUO(id): void {
    this.http.get<any[]>(this.link + 'uniteopera/dto/' + id)
      .subscribe(data => {
        this.UO = data;
        this.disabledUO = false;
      });
  }

  loadServices(): void {
    this.http.get<any[]>(this.link + 'services/dto' )
      .subscribe(data => {
        this.Services = data;
      });
  }

  onChangeSociete(event): void {
    if(event != null){
    this.utilisateurmodel.societe = event;
    if( Array.isArray(this.utilisateurmodel?.societe)){
      this.loadUO(event[0].id);
      this.utilisateurmodel.uo = null;
      this.utilisateurmodel.service = null;
    }else{
      this.loadUO(event.id);
      this.utilisateurmodel.uo = null;
      this.utilisateurmodel.service = null;
    }
  }
  }

  onChangeUO(event): void {
    if(event != null){
      this.utilisateurmodel.uo = event;
    }
  }

  onChangePoste(event): void {
    if( Array.isArray(event)){
      this.utilisateurmodel.poste = event;
    }
  }

  onChangeManager(event): void {
    if( Array.isArray(event)){
      this.utilisateurmodel.manager = event[0];
    }
  }

}

import { Component, OnInit } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpClient } from '@angular/common/http';
import { NbWindowService } from '@nebular/theme';
import { DataService } from '../../../services/data.service';
import { TickComponent } from '../../../components/tick/tick.component';
import { StatusComponent } from '../../../components/status/status.component';
import { environment } from '../../../../environments/environment.prod';
import { WindowFormComponent } from '../../../window-form/window-form.component';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'ngx-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  private link = environment.linklocal + "utilisateur/";

  data: any = {};
  settings = {
    actions: {
      add : false,
      edit : false,
      delete : false
    },
    mode: 'external',
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',

    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    columns: {
      matricule: {
        title: 'Matricule',
        type: 'number',
        editable: false,
      },
      prenom: {
        title: 'Prénom',
        type: 'string',

      },
      nom: {
        title: 'Nom',
        type: 'string',
      },
      mail: {
        title: 'E-mail',
        type: 'string',
      },
      poste: {
        title: 'Poste',
        type: 'string',
        valuePrepareFunction: (cell, row) => {
          if (row.poste != null) {
            return row.poste.name;
          }
        }
      },
      societe: {
        title: 'Société',
        type: 'string',
        valuePrepareFunction: (cell, row) => {
          if (row.societe != null) {
            return row.societe.name;
          }
        }
      },
      uo: {
        title: 'Unite Opérationnelle',
        type: 'string',
        valuePrepareFunction: (cell, row) => {
          if (row.uo != null) {
            return row.uo.name;
          }
        }
      },
      service: {
        title: 'Service',
        type: 'string',
        valuePrepareFunction: (cell, row) => {
          if (row.service != null) {
            return row.service.name;
          }
        }
      },
      integStatut: {
        title: "Session d'intégration",
        type: 'custom',
        renderComponent: StatusComponent,

      },
      integRange: {
        title: "Date d'intégration",
        type: 'string',
      },
      docs: {
        title: "Documents de safran",
        type: 'custom',
        renderComponent: TickComponent,
      },

      Formation: {
        title: "Formations obligatoires",
        type: 'custom',
        renderComponent: TickComponent,
      },
    },



  };

  source: LocalDataSource = new LocalDataSource();

  constructor(private http: HttpClient, private windowService: NbWindowService, private dataService: DataService, private datePipe: DatePipe) {

  }
  ngOnInit(): void {
    this.loadEffectifs();
  }
  rowVar(event: any): void {

    const data = event.data;
    this.dataService.formData = data;

  }
  onEdit(event): void {
    this.windowService.open(WindowFormComponent, {
      title: 'Modifier collaborateur',
      context: {
        employee: event.data, // pass the employee data to the window
      },
    }).onClose.subscribe(newData => {
      if (newData) {
        // update the employee data in the table
        event.confirm.resolve(newData);
      } else {
        event.confirm.reject();
      }
    });
  }
  loadEffectifs(): void {
    this.http.get<any[]>(this.link + 'get/all')
      .subscribe(data => {
        this.data = data.map(item => {
          // Format the "entree" value to the required format
          item.entree = this.datePipe.transform(item.entree, 'yyyy-MM-dd');
          return item;
        });
        this.source.load(this.data); // Assign the formatted data to the LocalDataSource
      });
  }



}

import { Component, Inject, OnInit } from '@angular/core';
import { NB_WINDOW_CONTEXT, NbToastrService, NbWindowRef, NbWindowService } from '@nebular/theme';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment.prod';
@Component({
  selector: 'ngx-certif-window',
  templateUrl: './certif-window.component.html',
  styleUrls: ['./certif-window.component.scss']
})
export class CertifWindowComponent implements OnInit {
  formationId: number;
  fileToUpload: any;
  private link = environment.linklocal+"certificate/";
  constructor(private http: HttpClient, private toastr: NbToastrService,    private windowRef: NbWindowRef, 

  @Inject(NB_WINDOW_CONTEXT) context: any
  ) {
    this.formationId = context.formationId;
  }
  ngOnInit(): void {

  }
  changeFile(evt) {
    this.fileToUpload = evt.target.files[0];
 }
 upload(): void {
  if (!this.fileToUpload || this.fileToUpload.size === 0) {
    this.toastr.warning("Veuillez joindre votre certificat obtenu", "Attention!");
  } else {
    const formData = new FormData();
    formData.append('file', this.fileToUpload);
    formData.append('formationId', this.formationId.toString());

    this.http.post<any>(this.link+'add', formData).subscribe(
      () => {
        this.toastr.success('Ajouté avec succès', 'Succès');
        this.windowRef.close();
      },
      (error) => {
       // console.log(error);
        this.toastr.danger('Erreur lors de l\'ajout de la formation', 'Erreur');
      }
    );
  }
}

 }


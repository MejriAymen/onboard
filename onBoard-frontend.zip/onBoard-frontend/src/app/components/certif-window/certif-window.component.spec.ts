import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CertifWindowComponent } from './certif-window.component';

describe('CertifWindowComponent', () => {
  let component: CertifWindowComponent;
  let fixture: ComponentFixture<CertifWindowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CertifWindowComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CertifWindowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

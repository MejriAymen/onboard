import { HttpClient } from '@angular/common/http';
import { Component, OnInit, Inject, EventEmitter, Output } from '@angular/core';
import { NbToastrService, NbWindowRef } from '@nebular/theme';
import { NB_WINDOW_CONTEXT } from '@nebular/theme';
import { LocalDataSource } from 'ng2-smart-table';
import { environment } from '../../../environments/environment.prod';


@Component({
  selector: 'ngx-List-certif',
  templateUrl: './List-certif.component.html',
  styleUrls: ['./List-certif.component.scss']
})
export class ListCertifComponent implements OnInit {
  source: LocalDataSource = new LocalDataSource();
  private link = environment.linklocal;

  settings = {
    actions: {
      add: false,
      edit: false,
      delete: false,
    },
    mode: 'external',
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',

    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    columns: {
      prenom: {
        title: 'Prenom',
        type: 'string',

      },
      nom: {
        title: 'Nom',
        type: 'string',

      },
      mail: {
        title: 'E-mail',
        type: 'string',

      },
      certificate :{
        title: 'Certificate',
        type: 'string',
      }
    },
  };
  formationId: any;
  data: any[];
  certificates: {
    certificate: string,
    mail  : string,
    nom : string,
    prenom  : string,
  }[] = [];
  @Output() formationEdited = new EventEmitter<any>();
  constructor(
    private http: HttpClient,
    @Inject(NB_WINDOW_CONTEXT) context: any
  ) {
    this.formationId = context.formation.idFormation;
  }


  ngOnInit(): void {
    this.http.get<any[]>(this.link + 'certificates/get/' + this.formationId)
      .subscribe((data : any[]) => {
        this.data = data;
        this.data.forEach(certif =>{
          this.certificates.push({
            certificate: certif.certificate,
            mail  : certif.utilisateur.mail,
            nom : certif.utilisateur.nom,
            prenom  : certif.utilisateur.prenom,
          });
        });
        this.source.load(this.certificates);
      });
  }

}

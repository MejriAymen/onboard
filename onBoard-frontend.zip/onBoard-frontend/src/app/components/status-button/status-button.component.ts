import { Component, Input } from '@angular/core';

@Component({
  template: `
    <button nbButton [status]="getStatus()" ghost>{{getStatusText()}}</button>
  `,
})
export class StatusButtonComponent {
  @Input() value: boolean;

  getStatus(): string {
    return this.value ? 'success' : 'danger';
  }

  getStatusText(): string {
    return this.value ? 'Confirmé' : 'Non confirmé';
  }
}

import { HttpClient } from '@angular/common/http';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'ngx-safran-table',
  templateUrl: './safran-table.component.html',
  styleUrls: ['./safran-table.component.scss'],
})
export class SafranTableComponent implements OnInit {
  @Input('tableData') tableData : [];
  @Input('cols') cols : string[];
  @Input('fields') fields : string[];
  @Input('pagination') pagination : Number = 10;
  @Output() selectedRows: EventEmitter<any[]> = new EventEmitter<any[]>();
  selectedRow : any[] = [];

  constructor(private http: HttpClient) {
  }

  ngOnInit(): void {
    this.selectedRow=[];
  }


onRowCheckboxChange( rowData: any) {
    const index = this.selectedRow.findIndex((row) => row.id === rowData.id);
    if (index !== -1) {
      this.selectedRow.splice(index, 1);
    }else{
      this.selectedRow.push(rowData)
    }
    this.selectedRows.emit(this.selectedRow);
}
}

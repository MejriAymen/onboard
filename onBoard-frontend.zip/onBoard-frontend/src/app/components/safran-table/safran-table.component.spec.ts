import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SafranTableComponent } from './safran-table.component';

describe('SafranTableComponent', () => {
  let component: SafranTableComponent;
  let fixture: ComponentFixture<SafranTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SafranTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SafranTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, Inject, OnInit } from '@angular/core';
import { NB_WINDOW_CONTEXT, NbToastrService, NbWindowRef, NbWindowService } from '@nebular/theme';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { environment } from '../../../environments/environment.prod';
@Component({
  selector: 'ngx-presentation-edit',
  templateUrl: './presentation-edit.component.html',
  styleUrls: ['./presentation-edit.component.scss']
})
export class PresentationEditComponent implements OnInit {
  fileToUpload: any;
  presentationEditForm: FormGroup;
  presentation: any;
  private link = environment.linklocal+"presentation/";
  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private toastr: NbToastrService,
    private windowRef: NbWindowRef,
    @Inject(NB_WINDOW_CONTEXT) context: any
  ) {
    this.presentation = context.presentation;
  }

  ngOnInit(): void {
    this.presentationEditForm = this.fb.group({
      titre: ['', Validators.required],
      description: ['', Validators.required],
      file: [null],
    });
    this.presentationEditForm.patchValue({
      titre: this.presentation.presentationTitle,
      description: this.presentation.presentationDesc
    });
  }
  onConfirm(event: Event): void {
    event.preventDefault();
  
    if (this.presentationEditForm.invalid) {
      this.toastr.warning('Tous les champs sont obligatoires','ATTENTION!');
      return;
    }
    this.upload();}
  changeFile(evt) {
    this.fileToUpload = evt.target.files[0];
  }
  upload(): void {
    if (this.presentationEditForm.invalid) {
      this.toastr.warning('Tous les champs sont obligatoires', 'ATTENTION!');
      return;
    }
  
    const formData = new FormData();
    const fileToUpload = this.fileToUpload;
  
    if (fileToUpload) {
      formData.append('file', fileToUpload);
    } else {
      // Create an empty file with a dummy name
      const emptyFile = new File([], 'empty.txt');
      formData.append('file', emptyFile);
    }
    
    formData.append('presentationDesc', this.presentationEditForm.get('description').value);
    formData.append('titlePresentation', this.presentationEditForm.get('titre').value);
    
    this.http.put<any>(this.link+'update/'+this.presentation.idPresentation, formData).subscribe(
      () => {
        window.location.reload();
      },
      (error) => {
       // console.log(error);
        this.toastr.danger('Erreur lors de l\'ajout de la formation', 'Erreur');
      }
    );
  }
  
  
  }
  

import { HttpClient } from '@angular/common/http';
import { Component, OnInit, Inject, EventEmitter, Output } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NbToastrService, NbWindowRef } from '@nebular/theme';
import { NB_WINDOW_CONTEXT } from '@nebular/theme';
import { environment } from '../../../environments/environment.prod';
interface Formation {
  id: number;
  titleForm: string;
  description: string;
  departement: string;
  link: string;
  imageFormation: string;
  obligatoiry: boolean;
}

@Component({
  selector: 'ngx-formation-edit',
  templateUrl: './formation-edit.component.html',
  styleUrls: ['./formation-edit.component.scss']
})
export class FormationEditComponent implements OnInit {
  departements: string[] = [];
  private link = environment.linklocal;

  SensibilisationForm: FormGroup;
  formationId: any;
  @Output() formationEdited = new EventEmitter<any>();
  fileToUpload: any;
  image: string;
  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private toastr: NbToastrService,
    private windowRef: NbWindowRef,
    @Inject(NB_WINDOW_CONTEXT) context: any
  ) {
    this.formationId = context.formation;
  }


  ngOnInit(): void {


    // Initialize form group with validators
    this.SensibilisationForm = this.fb.group({

      titre: ['', Validators.required],
      description: ['', Validators.compose([
        Validators.required,
        this.customValidator()
      ])],
      departement: [''],
      lien: ['', Validators.required],
      image: [''],
      obligatoire: ['', Validators.required],
      generique: ['', Validators.required]
    });

    this.http.get<any[]>(this.link + 'services/dto')
    .subscribe(data => {
      this.departements = data;
    });
    // Make API call to get default values for form inputs
    this.http
      .get<any>(this.link + `formations/get/${this.formationId.idFormation}`)
      .subscribe(data => {
        this.image = data.imageFormation;
        // Set default values for form controls
        this.SensibilisationForm.patchValue({
          titre: data.titleForm,
          description: data.description,
          departement: data.departement,
          lien: data.link,
          obligatoire: data.isObligatory,
          generique: data.isGeneric
        });


        this.SensibilisationForm.get('departement').setValue(data.departement);

      });
  }

  // Custom validator for description field
  customValidator() {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const value = control.value;
      if (value && value.trim().length < 10) {

      }
      return null;
    };
  }



  onConfirm(event: Event): void {
    event.preventDefault();
    if (this.SensibilisationForm.invalid) {
      this.toastr.warning('Tous les champs sont obligatoires', 'ATTENTION!');
      return;
    }

    this.submitForm();
  }
  changeFile(evt) {
    this.fileToUpload = evt.target.files[0];
  }
  submitForm(): void {

    const imageFile = this.fileToUpload;
    // const formData = {
    //   titleForm: this.SensibilisationForm.value.titre,
    //   description: this.SensibilisationForm.value.description,
    //   departement: this.SensibilisationForm.value.departement,
    //   link: this.SensibilisationForm.value.lien,
    //   obligatory: this.SensibilisationForm.value.obligatoire,

    // };
    const formData = new FormData()
    if (imageFile) {
      formData.append('imageFormation', imageFile);
    } else {
      const emptyFile = new File([], 'empty.txt');
      formData.append('imageFormation', emptyFile);
    }
    formData.append('titleFormation', this.SensibilisationForm.get('titre').value);
    formData.append('description', this.SensibilisationForm.get('description').value);
    formData.append('departement', this.SensibilisationForm.get('departement').value);
    formData.append('link', this.SensibilisationForm.get('lien').value);
    formData.append('isObligatory', this.SensibilisationForm.get('obligatoire').value);
    formData.append('isGeneric', this.SensibilisationForm.get('generique').value);
    this.http.put<Formation>(this.link + 'formations/update/' + this.formationId.idFormation, formData)
      .subscribe(
        () => {
          this.toastr.success('Ajouté avec succès', 'Succès');
          window.location.reload();
          this.windowRef.close();
        },
        (error) => {
         // console.log(error);
          this.toastr.danger('Erreur lors de l\'ajout de la formation', 'Erreur');
        }
      );
  }
}

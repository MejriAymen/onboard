import { Component, Input } from '@angular/core';
import { NbDialogRef } from '@nebular/theme';

@Component({
  selector: 'ngx-confirmation-dialog',
  styleUrls: ['./confirmation-dialog.component.scss'],
  template: `
    <nb-card class="confirmation">
      <nb-card-header>{{ title }}</nb-card-header>
      <nb-card-body>{{ message }}</nb-card-body>
      <nb-card-footer>
        <button nbButton status="danger" (click)="close(false)">Non</button>
        <button nbButton status="success" (click)="close(true)">Oui</button>
      </nb-card-footer>
    </nb-card>
  `,
})
export class ConfirmationDialogComponent {
  @Input() title: string;
  @Input() message: string;

  constructor(private dialogRef: NbDialogRef<any>) {}

  close(result: boolean): void {
    this.dialogRef.close(result);
  }
}

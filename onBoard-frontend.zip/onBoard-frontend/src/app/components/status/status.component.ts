import { Component, Input, OnInit } from '@angular/core';

@Component({
  template: `
      <button nbButton [status]="getIntegStautStatus()" ghost>{{getIntegStautText()}}</button>
  `,
})
export class StatusComponent implements OnInit  {
  @Input() value: string;

  ngOnInit () {
  }
  getIntegStautText(): string {
     if (this.value === 'NOUVEAU') {
      return 'NOUVEAU';
    } else if (this.value === 'REPORTE') {
      return 'Reporté';
    } else if (this.value === 'ABSENT') {
      return 'Absent';
    } else if (this.value === 'FIGE') {
      return 'Figé';
    } else if (this.value === 'INVITE') {
      return 'invité';
    } else{
      return 'Présent';
    }
  }

  getIntegStautStatus(): string {
    if (this.value === 'NOUVEAU') {
      return 'basic';
    } else if (this.value === 'REPORTE' || this.value === 'ABSENT') {
      return 'warning';
    } else if (this.value === 'FIGE') {
      return 'danger';
    } else {
      return 'success';
    }
  }
}

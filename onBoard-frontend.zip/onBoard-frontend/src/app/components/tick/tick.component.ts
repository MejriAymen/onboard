import { Component, Input } from '@angular/core';

@Component({
  template: `
    <nb-icon [icon]="getStatusIcon()" [status]="getStatus()"></nb-icon>
  `,
})
export class TickComponent {
  @Input() value: boolean;

  getStatus(): string {
    return this.value ? 'success' : 'danger';
  }

  getStatusIcon(): string {
    return this.value ? 'checkmark-outline' : 'close-outline';
  }
}

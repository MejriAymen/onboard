import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit,Inject, EventEmitter, Output } from '@angular/core';
import {FormBuilder, FormGroup, Validators } from '@angular/forms';
import {  NbToastrService, NbWindowRef} from '@nebular/theme';
import { NB_WINDOW_CONTEXT } from '@nebular/theme';
import { map } from 'rxjs/operators';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { environment } from '../../../environments/environment.prod';
@Component({
  selector: 'ngx-edit-field',
  templateUrl: './edit-field.component.html',
  styleUrls: ['./edit-field.component.scss']
})
export class EditFieldComponent implements OnInit {
  fieldForm: FormGroup;
field:any;
  dropdownSettings: IDropdownSettings;
  interlocuteurs:any;
  presentation:String;
  public selectedInterlocuteurs: any[] = [];
  private link = environment.linklocal;
  constructor(    private fb: FormBuilder,    private http: HttpClient,private toastr: NbToastrService,private windowRef: NbWindowRef, 


     @Inject(NB_WINDOW_CONTEXT) context: any
    ) {this.field = context.field; }

  ngOnInit(): void {
    this.loadinterlocuteur();
    this.presentation=this.field.presentation
    this.fieldForm = this.fb.group({
      from: ['', Validators.required],
      to: ['', Validators.required],
      presentation: [''],
      interlocuteurs: [null]});
      this.dropdownSettings= {
        singleSelection: false,
        idField: 'id',
        textField: 'fullName',
        itemsShowLimit: 3,
        allowSearchFilter: true,
        maxHeight:200,
        searchPlaceholderText:'Chercher un animateur interne',
        closeDropDownOnSelection: true
      };
      this.fieldForm.patchValue({
        presentation : this.field.presentation,
        from : this.field.fieldFrom,
        to : this.field.fieldTo,
       interlocuteurs:this.field.interlocuteurs
      })
      this.selectedInterlocuteurs = this.field.interlocuteurs;
      this.fieldForm.get('interlocuteurs').setValue(this.selectedInterlocuteurs);
      }

      loadinterlocuteur(): void {
        this.http.get<any[]>(this.link + 'utilisateur/get/animatorslight')
          .subscribe(data => {
            this.interlocuteurs = data;
          });
      }

      updateField() {
        
        if (this.fieldForm.valid) {
          const formData = {
            day: this.field.day,
            fieldFrom: this.fieldForm.value.from,
            fieldTo: this.fieldForm.value.to,
            interlocuteurs: this.fieldForm.value.interlocuteurs,
            presentation: this.fieldForm.value.presentation
          };

          this.http.put(this.link+'fields/update/'+this.field.idField, formData)
            .subscribe(() => {
              window.location.reload();

            }, (error) => {
            //  console.log(error);
              this.toastr.danger('Erreur lors de la modification', 'Erreur');
            });
        }else{
          this.toastr.warning('Tous les champs sont obmigatoires','ATTENTION!');
        }
      
      }
      
}

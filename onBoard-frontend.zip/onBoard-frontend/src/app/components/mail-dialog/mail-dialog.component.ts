import { Component, Input } from '@angular/core';
import { NbDialogRef } from '@nebular/theme';

@Component({
  selector: 'ngx-mail-dialog',
templateUrl: './mail-dialog.component.html',
styleUrls: ['./mail-dialog.component.scss'],


})
export class MailDialogComponent {
  @Input() title: string;
  @Input() items: any[];

  constructor(private dialogRef: NbDialogRef<any>) { }

  onSelect(item: any): void {
    item.checked = !item.checked;
  }

  confirmSelection(): void {
    const selectedItems = this.items.filter(item => item.checked);
    this.dialogRef.close(selectedItems);
  }

  close(result: any): void {
    this.dialogRef.close(result);
  }
}

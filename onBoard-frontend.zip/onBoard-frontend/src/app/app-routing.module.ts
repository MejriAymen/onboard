import { ExtraOptions, RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './_guards/auth.guard';
import { AuthService } from './services/auth.service';
import { JwtHelperService, JWT_OPTIONS } from '@auth0/angular-jwt';

export const routes: Routes = [

  {
    path: 'auth',
    component: LoginComponent
  },
  {
    path: 'pages',
    loadChildren: () => import('./pages/pages.module')
      .then(m => m.PagesModule),
  },
  {
    path: 'animateurs',
    loadChildren: () => import('./animator/animator.module')
      .then(m => m.AnimatorModule),
  },
  {
    path: 'collaborateurs',
    canActivate: [AuthService],
    loadChildren: () => import('./collaborateurs/collaborateurs/collaborateurs.module')
      .then(m => m.CollaborateursModule),
  },

  { path: '', redirectTo: '/auth', pathMatch: 'full' },
  { path: '**', redirectTo: '/auth' },
];

const config: ExtraOptions = {
  useHash: false,
};

@NgModule({
  imports: [RouterModule.forRoot(routes, config), RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule],
  providers: [AuthGuard, AuthService, { provide: JWT_OPTIONS, useValue: JWT_OPTIONS },
    JwtHelperService]
})
export class AppRoutingModule {
}

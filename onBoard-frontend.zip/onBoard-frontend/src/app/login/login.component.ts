import { DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NbIconLibraries } from '@nebular/theme';
import { AuthService } from '../services/auth.service';


@Component({
  selector: 'ngx-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted = false;
  invalidCredentials: boolean = false;
  evaIcons = [];
  loading: boolean;
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    public authService: AuthService,
    public datepipe: DatePipe
    , iconsLibrary: NbIconLibraries
  ) {
    this.evaIcons = Array.from(iconsLibrary.getPack('eva').icons.keys())
      .filter(icon => icon.indexOf('outline') === -1);
  }

  get f() { return this.loginForm.controls; }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      identifiant: [null, Validators.required],
      ps: [null, Validators.required]
    });
  }

  tryLogin() {
    if (!this.loginForm.invalid) {
      this.submitted = true;
      const value = {
        username: this.f.identifiant.value,
        ps: this.f.ps.value
      };
      this.authService.login(value).subscribe(
        (response: any) => {
          localStorage.clear();
          this.setUserInStorage(response);
          localStorage.removeItem('currentLayoutStyle');
          if (response.token != null) {
            localStorage.setItem('token', response.token);
          }
          if (response.userloged != null) {
            localStorage.setItem('currentUserOnBoard', JSON.stringify(response.userloged));
          }
          let date = new Date();
          let loginDate = this.datepipe.transform(date, 'yyyy-MM-dd HH:MM:ss');
          localStorage.setItem('loginDate', loginDate);
          localStorage.setItem('loggedinOnBoard', "true");
          this.submitted = false;
          if (response.userloged.role.id == 4) {
            this.router.navigate(['/collaborateurs']);
          } else if (response.userloged.role.id == 1) {
            this.router.navigate(['/pages']);
          } else if (response.userloged.role.id == 3) {
            this.router.navigate(['/animateurs']);
          }
          this.loading = false;
        },
        (error: HttpErrorResponse) => {
          this.loading = false;
          this.submitted = false;
          this.invalidCredentials = true;
        }
      );
    }
  }

  setUserInStorage(response) {
    if (response.userloged) {
      localStorage.setItem('currentUserOnBoard', JSON.stringify(response.userloged));
    } else {
      localStorage.setItem('currentUserOnBoard', JSON.stringify(response));
    }
  }
}

export interface Calendar {
    title: string;
    description: string;
    startDate: Date;
    endDate: Date;
    customFields: CustomField[];
  }
  
  export interface CustomField {
    name: string;
    type: string;
  }
  
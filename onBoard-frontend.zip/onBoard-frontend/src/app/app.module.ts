/**
 * @license
 * Copyright Akveo. All Rights Reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 */

import { CollaborateursModule } from './collaborateurs/collaborateurs/collaborateurs.module';
import { CoreModule } from './@core/core.module';
import { BrowserModule, HammerGestureConfig, HAMMER_GESTURE_CONFIG } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ThemeModule } from './@theme/theme.module';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import {
  NbChatModule,
  NbDatepickerModule,
  NbDialogModule,
  NbMenuModule,
  NbSidebarModule,
  NbToastrModule,
  NbWindowModule,
  NbIconModule,
  NbCardModule,
  NbActionsModule,
  NbRadioModule,
  NbSelectModule,
  NbListModule
} from '@nebular/theme';
import { WindowFormComponent } from './window-form/window-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NbInputModule, NbButtonModule, NbCheckboxModule, } from '@nebular/theme';
import { ConfirmationDialogComponent } from './components/confirmation-dialog/confirmation-dialog.component';
import { MailDialogComponent } from './components/mail-dialog/mail-dialog.component';
import { NbTreeGridModule } from '@nebular/theme';
import { StatusButtonComponent } from './components/status-button/status-button.component';
import { TickComponent } from './components/tick/tick.component';
import { StatusComponent } from './components/status/status.component';
import { TableModule } from 'primeng/table';
import { HomeComponent } from './collaborateurs/home/home.component';
import { FormationComponent } from './collaborateurs/formation/formation.component';
import { DocsComponent } from './collaborateurs/docs/docs.component';
import { EvaluationComponent } from './collaborateurs/evaluation/evaluation.component';
import { CertifWindowComponent } from './components/certif-window/certif-window.component';
import { MatSliderModule } from '@angular/material/slider';
import { FormationEditComponent } from './components/formation-edit/formation-edit.component';
import { PresentationEditComponent } from './components/presentation-edit/presentation-edit.component';
import { SessionsComponent } from './collaborateurs/sessions/sessions.component';
import { EditFieldComponent } from './components/edit-field/edit-field.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { RouterModule } from '@angular/router';
import { TokenInterceptor } from './services/TokenInterceptor';
import { LoginModule } from './login/login/login.module';
import { ListCertifComponent } from './components/List-certif/List-certif.component';
import { Ng2SmartTableModule } from 'ng2-smart-table';

@NgModule({
  declarations: [AppComponent,
    WindowFormComponent,
    ConfirmationDialogComponent,
    MailDialogComponent,
    StatusButtonComponent,
    TickComponent,
    StatusComponent,
    HomeComponent,
    FormationComponent,
    DocsComponent,
    EvaluationComponent,
    CertifWindowComponent,
    FormationEditComponent,
    ListCertifComponent,
    PresentationEditComponent,
    SessionsComponent,
    EditFieldComponent],
  imports: [
    Ng2SmartTableModule,
    PdfViewerModule,
    NgMultiSelectDropDownModule,
    NbSelectModule,
    NbListModule,
    NbRadioModule,
    MatSliderModule,
    NbActionsModule,
    CollaborateursModule,
    TableModule,
    NbCardModule,
    NbCheckboxModule,
    NbIconModule, NbTreeGridModule,
    ReactiveFormsModule,
    NbCardModule,
    FormsModule,
    NbInputModule,
    NbButtonModule,
    FormsModule,
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    AppRoutingModule,
    LoginModule,
    NbSidebarModule.forRoot(),
    NbMenuModule.forRoot(),
    NbDatepickerModule.forRoot(),
    NbDialogModule.forRoot(),
    NbWindowModule.forRoot(),
    NbToastrModule.forRoot(),
    NbChatModule.forRoot({
      messageGoogleMapKey: 'AIzaSyA_wNuCzia92MAmdLRzmqitRGvCF7wCZPY',
    }),
    CoreModule.forRoot(),
    ThemeModule.forRoot(),
  ],

  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    }],



  bootstrap: [AppComponent],
  exports: [RouterModule]
})
export class AppModule {
}

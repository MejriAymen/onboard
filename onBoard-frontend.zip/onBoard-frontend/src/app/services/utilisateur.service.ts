import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment.prod';
import { Contacts, RecentUsers } from '../@core/data/users';

@Injectable({
  providedIn: 'root'
})
export class UtilisateurService {

  // private apiurl ='http://dhari-app:8080/check'
  private time: Date = new Date;

  private apiurl = environment.linklocal;
  private nom = localStorage.getItem("username");
  private users = {
    nick: { name: this.nom, picture: 'assets/images/bt.png' },

  };
  private types = {
    mobile: 'mobile',
    home: 'home',
    work: 'work',
  };
  private contacts: Contacts[] = [
    { user: this.users.nick, type: this.types.mobile },

  ];
  private recentUsers: RecentUsers[] = [

    { user: this.users.nick, type: this.types.mobile, time: this.time.setHours(5, 29) },

  ];
  constructor(private http: HttpClient) { }

  public getallUtilisateur(): Observable<any> {
    return this.http.get<any>(`${this.apiurl}utilisateur/listutilisateur`)
  }

  public getNombreUtilisateur(): Observable<any> {
    return this.http.get<any>(`${this.apiurl}utilisateur/nombre`);
  }


  //delete
  public deleteUtilisateur(id: number): Observable<any> {
    return this.http.delete(`${this.apiurl}utilisateur/delete/${id}`, { responseType: 'text' });
  }


  public DesactiverUtilisateur(u: any): Observable<any> {
    return this.http.put<any>(`${this.apiurl}utilisateur/desactiver`, u)
  }

  public add(f: any): Observable<any> {
    return this.http.post<any>(`${this.apiurl}utilisateur/add`, f)
  }
  //Update Utilisateur:
  public update(f: any): Observable<any> {
    return this.http.put<any>(`${this.apiurl}utilisateur/update`, f)
  }


  public renitialiser(f: any): Observable<any> {
    return this.http.put<any>(`${this.apiurl}utilisateur/renitialiser`, f)
  }

  public searchuser(username: string): Observable<any> {
    return this.http.get<any>(`${this.apiurl}searchusername/` + username)
  }

  public addusers(data: any, nom: string, prenom: string, username: string, mail: string, role: any): Observable<any> {
    data.nom = nom;
    data.prenom = prenom;
    data.login = username;
    data.mail = mail;
    data.role = {id :role.id,
      intitule: role.role
    };
    return this.http.post<any>(`${this.apiurl}register`, data);
  }

  public deleteAnimator(id: number): Observable<any> {
    return this.http.delete(`${this.apiurl}utilisateur/delete/animator/${id}`, { responseType: 'text' });
  }

  public addAnimators(data: any): Observable<any> {
    return this.http.put<any>(`${this.apiurl}utilisateur/add/animateurs`, data);
  }
}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment.prod';

const jwtHelper = new JwtHelperService();

@Injectable()
export class AuthService {
  private apiurl = environment.linklocal;
  constructor(private http: HttpClient,
    private router: Router
  ) { }
  public login(data: any): Observable<any> {
    var datacnx = {
      "username": data.username,
      "password": data.ps
    }
    return this.http.post<any>(this.apiurl + "authenticate", datacnx)
  }

  public isAuthenticated(): boolean {
    const token = localStorage.getItem('token');

    if ((localStorage.getItem("loggedinOnBoard") == "false")
      || (jwtHelper.isTokenExpired(token))) {
      return false;
    } else {
      return true;
    }
  }



  logout() {
    if (localStorage.getItem('currentUserPortail')) {
      localStorage.clear();
      localStorage.setItem("loggedinPortail", "false");
      this.router.navigate(["/login"]);
    }
    //console.log(localStorage.getItem('currentUserPortail'));
  }

  logoutRedirection() {
    if (localStorage.getItem('currentUserPortail')) {
      localStorage.clear();
      localStorage.setItem("loggedinPortail", "false");
    }
  }
}

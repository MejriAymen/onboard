import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  getDomains() {
    throw new Error('Method not implemented.');
  }
  formData: any = {};
}

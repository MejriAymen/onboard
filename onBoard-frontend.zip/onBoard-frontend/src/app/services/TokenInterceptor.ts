import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {



  intercept(request: HttpRequest<any>, next: HttpHandler) {
    //console.log(localStorage.getItem("token"));

    if ((request.url.substring(request.url.length - 12, request.url.length) != "authenticate")  ) {
     
      
        request = request.clone({
        setHeaders: {
          'Access-Control-Allow-Origin': '*',
          Authorization: `Bearer ${localStorage.getItem("token")}`
        }
      });
    }
    else request = request.clone({
      setHeaders: {
        'Access-Control-Allow-Origin': '*'
      }
    });
    return next.handle(request);
  }



  
}
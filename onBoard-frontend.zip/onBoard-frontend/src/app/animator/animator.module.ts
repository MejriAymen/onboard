import { NgModule } from '@angular/core';
import { NbAccordionModule, NbCardModule, NbCheckboxModule, NbMenuModule, NbRadioModule } from '@nebular/theme';
import { AnimatorRoutingModule } from './animator-routing.module';
import { ThemeModule } from '../@theme/theme.module';
import { AnimatorComponent } from './animator.component';
import { PresentationsComponent } from './presentations/presentations.component';
import { SessionsComponent } from './sessions/sessions.component';
import { PlanningsComponent } from './plannings/plannings.component';
import { PresenceComponent } from './presence/presence.component';



@NgModule({
  imports: [
    AnimatorRoutingModule,
    ThemeModule,
    NbMenuModule,
    NbCardModule,
    NbAccordionModule,
    NbCheckboxModule,
    NbRadioModule,

  ],
  declarations: [
    AnimatorComponent,
    PresentationsComponent,
    SessionsComponent,
    PlanningsComponent,
    PresenceComponent
  ],
  
  bootstrap: [AnimatorModule]
})
export class AnimatorModule {
}

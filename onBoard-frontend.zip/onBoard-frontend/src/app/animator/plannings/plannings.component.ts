import { Component, OnInit, ElementRef, TemplateRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
import { EditFieldComponent } from '../../components/edit-field/edit-field.component';
import { NbToastrService, NbWindowRef, NbWindowService } from '@nebular/theme';
import { environment } from '../../../environments/environment.prod';

@Component({
  selector: 'ngx-plannings',
  templateUrl: './plannings.component.html',
  styleUrls: ['./plannings.component.scss']
})
export class PlanningsComponent implements OnInit {
  private link = environment.linklocal + "plannings/";

  title: string;
  htmlContent: any;
  plannings: any[];
  planning = {
    idPlan: 0,
    titlePlan: '',
    fields: []
  };
  daysList: any[];
  pausesArray: any[];
  windowRef: NbWindowRef;
  newName="";
  idPlan: number;
  constructor(private http: HttpClient, private toastr: NbToastrService, private windowService: NbWindowService) { }

  openPrintWindow(index: number) {
    const printWindow = window.open('', '_blank');
    const printDocument = document.createElement('div');
    printDocument.innerHTML = document.getElementById(`print-section-${index}`).innerHTML;
    printWindow.document.open();
    printWindow.document.write(`
      <html>
        <head>
          <title>Print Window</title>
          <style>
          table {
            border-collapse: collapse;
            margin: auto;
            width: 100%;
            max-width: 800px;
            font-family: Arial, sans-serif;
            font-size: 14px;
          }

          th,
          td {
            padding: 10px;
            text-align: center;
            border: 2px solid #333;
          }

          th {
            background-color: #ACB9CA;
            color: black;
            font-weight: bold;
          }

          td:nth-child(odd) {
            background-color: #f2f2f2;
          }

          td[colspan="2"] {
            background-color: #d9e1f2;
            font-weight: bold;
          }

          td:first-child,
          th:first-child {
            width: 15%;
          }

          td:nth-child(2),
          th:nth-child(2) {
            width: 55%;
          }

          td:last-child,
          th:last-child {
            width: 30%;
          }

          b {
            font-weight: bold;
          }
        </style>
        </head>
        <body>
          ${printDocument.innerHTML}
          <script type="text/javascript">
            // Print the window automatically once it loads
            window.onload = function() {
              window.print();
              window.onafterprint = function() {
                window.close(); // Close the print window after printing
              }
            }
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  }

  duplicatedPlanDialog(dialog: TemplateRef<any>,id : number) {
    this.newName = "";
    this.idPlan = id ;
    this.windowRef = this.windowService.open(dialog);
  }

  DuplicatedPlan() {
    this.http.post<any>(this.link + 'duplicated/' + this.idPlan, this.newName).subscribe(
      () => {
        this.toastr.success('Ajouté avec succès', 'Succès');
        this.GetAllData();
        this.windowRef.close();
      },
      (error) => {
        // console.log(error);
        this.toastr.danger('Erreur lors de l\'ajout ', 'Erreur');
      }
    );
  }


  ngOnInit() {
    this.GetAllData();
  }

  GetAllData() {
    this.http.get<any[]>(this.link + 'get/all')
      .subscribe(data => {
        this.plannings = data;
        this.plannings.forEach(plan => {
          const fields = plan.fields.sort((a, b) => {
            return a.fieldFrom.localeCompare(b.fieldFrom);
          });
          const daysList = this.days({ fields });
          this.planning = { idPlan: plan.idPlan, titlePlan: plan.titlePlan, fields };
          this.daysList = daysList;
        });
      });
  }

  onClick(field: any) {
    this.windowService.open(
      EditFieldComponent,
      { title: 'Modifier la présentation', windowClass: 'file-upload-modal', context: { field } } // Configuration for the modal window
    );
  }
  days(data: any): any {
    const days = new Set();
    for (const field of data.fields) {
      days.add(field.day);
    }
    const uniqueDays = [...days];
    return uniqueDays;
  }


  changeNamePlan(event){
//this.newName = event;
  }
}

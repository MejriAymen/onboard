import { Component, OnInit ,ElementRef} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment.prod';
import { NbToastrService } from '@nebular/theme';

@Component({
  selector: 'ngx-sessions',
  templateUrl: './sessions.component.html',
  styleUrls: ['./sessions.component.scss']
})
export class SessionsComponent implements OnInit {
  currentUserOnBoard : any ;
  AnimatorsSessions: any[];
  InviAnimatorsSessions: any[];
  private link = environment.linklocal;

  constructor(private http: HttpClient,private toastr: NbToastrService) {}
  ngOnInit() {
    this.currentUserOnBoard=JSON.parse( localStorage.getItem('currentUserOnBoard'));
  this.loadSessionsAnimateur();
  this.loadinvitationSessionsAnimateur();
  }

  loadinvitationSessionsAnimateur(): void {
    this.http.get<any[]>(this.link+"animateursession/session/invi/"+this.currentUserOnBoard.id)
      .subscribe(data => {
        this.InviAnimatorsSessions = data;
      });
  }
  loadSessionsAnimateur(): void {
    this.http.get<any[]>(this.link+"animateursession/session/"+this.currentUserOnBoard.id)
      .subscribe(data => {
        this.AnimatorsSessions = data;
      });
  }
  accept(event){
    this.http.get(this.link+'animateursession/update/'+event)
    .subscribe(() => {
      window.location.reload();

    }, (error) => {
      this.toastr.danger('Erreur lors de la modification', 'Erreur');
    });
  }
}
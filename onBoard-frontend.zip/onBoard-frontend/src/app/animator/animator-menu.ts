import { NbMenuItem } from '@nebular/theme';

export const MENU_ITEMS: NbMenuItem[] = [
  {
    title: 'Accueil',
    icon: 'home-outline',
    link: '/animateurs/dashboard',
    home: true
  },
  {
    title: 'Sessions',
    icon: 'code-outline',
    link: '/animateurs/sessions',
  },
  {
    title: 'Présentation',
    icon: 'book-outline',
    link: '/animateurs/presentation',
  },
  {
    title: 'Planning',
    icon: 'bookmark-outline',
    link: '/animateurs/planning',
  },
  {
    title: 'Présence',
    icon: 'bookmark-outline',
    link: '/animateurs/presence',
  },
];
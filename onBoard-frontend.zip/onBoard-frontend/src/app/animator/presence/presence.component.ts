import { Component, OnInit } from '@angular/core';
import { environment } from '../../../environments/environment.prod';
import { HttpClient } from '@angular/common/http';
import { NbToastrService } from '@nebular/theme';
//npm install xlsx
import * as XLSX from 'xlsx';
@Component({
  selector: 'ngx-presence',
  templateUrl: './presence.component.html',
  styleUrls: ['./presence.component.scss']
})
export class PresenceComponent implements OnInit {
  currentUserOnBoard : any ;
  AnimatorsSeances: any[];
  cols =  ['nom','prenom','mail'
  ];
  fields= ['Nom','Prenom','E-mail','Présence','Absence'
  ];
  private link = environment.linklocal;
  constructor(private http: HttpClient,private toastr: NbToastrService) { }

  ngOnInit(): void {
    this.currentUserOnBoard=JSON.parse( localStorage.getItem('currentUserOnBoard'));
    this.loadSessionsAnimateur();
  }
  loadSessionsAnimateur(): void {
    this.http.get<any[]>(this.link+"animateursession/session/today/"+this.currentUserOnBoard.id)
      .subscribe(data => {
        this.AnimatorsSeances = data;
      });
  }
  addPresence(id): void {
    console.log(id);
    this.http.get<any[]>(this.link+"seanceParticipants/update/"+id)
    .subscribe(data => {
      //console.log(data);
    });
  }
  downloadExcel(data): void  {
    const nomDoc = "Session N° "+ data.animateurSession.session.idSession + " Seance " + data.animateurSession.field.presentation +".xlsx";
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet([["Session N° "+ data.animateurSession.session.idSession]]); 
    XLSX.utils.sheet_add_aoa(ws, [[ data.animateurSession.session.debutSession +" => "+ data.animateurSession.session.finSession]], { origin: -1 });
    XLSX.utils.sheet_add_aoa(ws, [[ data.animateurSession.session.salle.name]], { origin: -1 });
    XLSX.utils.sheet_add_aoa(ws, [], { origin: -1 });
    XLSX.utils.sheet_add_aoa(ws, [[ "Présentation "+ data.animateurSession.field.presentation]], { origin: -1 });
    XLSX.utils.sheet_add_aoa(ws, [[ "Day N° "+ data.animateurSession.field.day]], { origin: -1 });   
    XLSX.utils.sheet_add_aoa(ws, [[  data.animateurSession.field.fieldFrom +" - "+ data.animateurSession.field.fieldTo]], { origin: -1 });
    XLSX.utils.sheet_add_aoa(ws, [[ "Aminé par  "+ data.animateurSession.animateur.nom + " " +data.animateurSession.animateur.prenom ]], { origin: -1 });
    XLSX.utils.sheet_add_aoa(ws, [], { origin: -1 });
    XLSX.utils.sheet_add_aoa(ws, [], { origin: -1 });
    XLSX.utils.sheet_add_aoa(ws, [["Nom", "Prénom","E-mail", "Statue"]], { origin: -1 });
    data.seanceParticipant.forEach((seanceP) => {
      const rowData = [seanceP.participant.nom, seanceP.participant.prenom, seanceP.participant.mail,seanceP.statue];
      XLSX.utils.sheet_add_aoa(ws, [rowData], { origin: -1 });
    });
 
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, nomDoc);
    }
}

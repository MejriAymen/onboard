import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { NotFoundComponent } from '../pages/miscellaneous/not-found/not-found.component';
import { AnimatorComponent } from './animator.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PresentationsComponent } from './presentations/presentations.component';
import { SessionsComponent } from './sessions/sessions.component';
import { PlanningsComponent } from './plannings/plannings.component';
import { PresenceComponent } from './presence/presence.component';

const routes: Routes = [{
  path: '',
  component: AnimatorComponent,
  children: [
    {
      path: '',
      component: DashboardComponent
    },
    {
      path: 'dashboard',
      component: DashboardComponent
    },
    {
      path: 'presentation',
      component: PresentationsComponent
    },
    {
      path: 'sessions',
      component: SessionsComponent
    },   
    {
      path: 'planning',
      component: PlanningsComponent
    },  
    {
      path: 'presence',
      component: PresenceComponent
    },
    {
      path: '**',
      component: NotFoundComponent,
    },
  ],
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AnimatorRoutingModule {
}

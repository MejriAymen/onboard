
export class utilisateur {
  id: number;
  matricule: string;
  nom: string;
  prenom: string;
  manager: string;
  mail:string;
  poste:any;
  uo:any;
  societe: any;
  service:any;
}

export class role
{
   id : number;
   intitule :string ;

}
export interface Fields {
    day: number;
   fieldFrom: string;
fieldTo: string;
interlocuteurs: any[];
presentation: string;
  }


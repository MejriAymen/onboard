export interface Plannings {
    idPlan: number;
    titlePlan: string;
    fields: any[];
}

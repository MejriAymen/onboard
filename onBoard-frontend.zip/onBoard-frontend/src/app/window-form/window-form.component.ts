import { Component } from '@angular/core';
import { NbWindowRef } from '@nebular/theme';
import { DataService } from '../services/data.service';
import { NbToastrService } from '@nebular/theme';
import { DatePipe } from '@angular/common';

@Component({
  template: `
   <form class="form">
  <label for="nom">Nom:</label>
  <input nbInput
         [(ngModel)]="formData.nom"
         #firstName="ngModel"
         id="firstName"
         type="text"
         name="firstName"
         placeholder="Nom"
         required>
  <ng-container *ngIf="firstName.invalid && firstName.touched"> 
    <p class="caption status-danger" *ngIf="firstName.errors?.required">
      Le nom est obligatoire!
    </p>
  </ng-container>

  <label for="lastName">Prénom:</label>
  <input nbInput
         [(ngModel)]="formData.prenom"
         #lastName="ngModel"
         id="lastName"
         type="text"
         name="lastName"
         placeholder="Prénom"
         required>
  <ng-container *ngIf="lastName.invalid && lastName.touched">
    <p class="caption status-danger" *ngIf="lastName.errors?.required">
      Le prénom est obligatoire!
    </p>
  </ng-container>


  <label for="poste">Poste:</label>
  <input nbInput
         [(ngModel)]="formData.poste"
         #poste="ngModel"
         id="poste"
         type="text"
         name="poste"
         placeholder="Poste"
         required>
  <ng-container *ngIf="poste.invalid && poste.touched">
    <p class="caption status-danger" *ngIf="poste.errors?.required">
      Le poste est obligatoire!
    </p>
  </ng-container>

  <label for="departement">Métier:</label>
  <input nbInput
         [(ngModel)]="formData.metier"
         #departement="ngModel"
         id="departement"
         type="text"
         name="departement"
         placeholder="Département"
         required>
  <ng-container *ngIf="departement.invalid && departement.touched">
    <p class="caption status-danger" *ngIf="departement.errors?.required">
      Le métier est obligatoire!
    </p>
  </ng-container>

  <label for="service">Domaine:</label>
  <input nbInput
         [(ngModel)]="formData.domaine"
         #service="ngModel"
         id="service"
         type="text"
         name="service"
         placeholder="Service/UO"
         required>
  <ng-container *ngIf="service.invalid && service.touched">
    <p class="caption status-danger" *ngIf="service.errors?.required">
      Le Service/UO est obligatoire!
    </p>
  </ng-container>

  <label for="dateDem">Date de démarrage:</label>
  <input nbInput
         [(ngModel)]="formData.entree"
         #dateDem="ngModel"
         id="dateDem"
         type="date"
         name="dateDem"
         placeholder="Date de démarrage"
         required>
  <ng-container *ngIf="dateDem.invalid && dateDem.touched">
    <p class="caption status-danger" *ngIf="dateDem.errors?.required">
      Le date de démarrage est obligatoire!
    </p>
  </ng-container>

  <label for="societe">Société:</label>
  <input nbInput
         [(ngModel)]="formData.societe"
         #societe="ngModel"
         id="societe"
         type="text"
         name="societe"
         placeholder="Société"
         required>
  <ng-container *ngIf="societe.invalid && societe.touched">
    <p class="caption status-danger" *ngIf="societe.errors?.required">
      Le champ société est obligatoire!
    </p>
  </ng-container>

  <label for="manager">Manager:</label>
 
  <input nbInput
         [(ngModel)]="formData.manager"
         #manager="ngModel"
         id="manager"
         type="text"
         name="manager"
         placeholder="Manager"
         required>
  <ng-container *ngIf="manager.invalid && manager.touched">
    <p class="caption status-danger" *ngIf="manager.errors?.required">
      Le champ manager est obligatoire!
    </p>
  </ng-container>
<div class="row col-md-4">
  <div class="buttons-group">
    <button nbButton status="success" (click)="save()">Confirmer</button> &nbsp;
    <button nbButton status="danger" (click)="cancel()">Annuler</button>
  </div>
  </div>
</form>


  `,
  styleUrls: ['window-form.component.scss'],
})
export class WindowFormComponent {
  formData: any = {};
  managers: string[] = [];

  constructor(public windowRef: NbWindowRef,private dataService: DataService,  private toastrService: NbToastrService, private datePipe: DatePipe
  ) {
    this.formData = dataService.formData}
  
    save() {
      // Check if all fields are filled
      if (this.formData.firstName && this.formData.lastName && this.formData.poste
          && this.formData.departement && this.formData.service
          && this.formData.dateDem && this.formData.societe
          && this.formData.manager) {
        //console.log(this.formData);
        this.windowRef.close();
      } else {
        // Show a warning toast if any field is empty
        this.toastrService.warning('Tous les champs sont obligatoires', 'ATTENTION');
      }
    }

  cancel() {
    this.windowRef.close();

  }
}

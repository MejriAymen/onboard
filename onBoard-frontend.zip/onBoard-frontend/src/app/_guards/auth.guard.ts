﻿import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from '../services/auth.service';


@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private router: Router, private auth: AuthService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (this.auth.isAuthenticated()) {
      const role = JSON.parse(localStorage.getItem('role'));
      switch (route.routeConfig.path) {
        case "login":
          return true;
        case "search":
          return role.id == "1" ? true : role.id == "2" ? true : false;
      }
      return true;
    }
    if (this.auth.isAuthenticated() == false && route.routeConfig.path == "mesrec") {
      return true;
    }
    localStorage.clear();
    localStorage.setItem("loggedinPortail", "false");
    this.router.navigate(['/login'], { queryParams: { returnPageUrl: state.url } });
    return false;
  }


}
